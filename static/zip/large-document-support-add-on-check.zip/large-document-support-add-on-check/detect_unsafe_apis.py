#!/usr/bin/env python3
"""
Deterministic detector for unsafe express-document-sdk APIs in an Adobe Express
add-on.

This is the DETERMINISTIC half of the Large Document Support add-on check skill. It scans an add-on
document-sandbox JS file for genuine usage of a fixed set of *named* unsafe
express-document-sdk APIs. Given the same input it always produces the same
output — no LLM, no judgment. It runs entirely outside the model's context
window, so it never consumes context on large minified bundles.

It intentionally does NOT try to detect the "held / leaked / stale reference"
patterns (holding a node across an async gap, persisting it between calls,
leaking it out of a safe-API callback). Those require dataflow reasoning and are
handled by the inline reference-pattern analysis in the skill. This script only
answers the reproducible question: "which named unsafe APIs are called, and
where?"

Named unsafe APIs (matched by member name, since receivers are typed/mangled):
    allChildren, artboards, allDescendants, allTextContent,
    cloneInPlace, queueAsyncEdit, bringIntoView

Precision note: matching is textual (regex), not AST. Comments/strings are NOT
stripped — a commented-out call would count as a hit. This is deliberate: it
keeps the detector dependency-free and safe (never risks eating real code and
missing a hit), and the skill's recall bias prefers false positives over misses.
Minified production bundles (the common case) have no comments anyway. An
AST-based upgrade (acorn/babel via Node) is possible if a parser is available,
but is not required.

Usage:
    python3 detect_unsafe_apis.py file <sandbox_js_path>
    python3 detect_unsafe_apis.py package <packageDir>

Both modes print JSON to stdout.
"""

import json
import os
import re
import sys

# The named unsafe API members.
UNSAFE_MEMBERS = [
    "allChildren",
    "artboards",
    "allDescendants",
    "allTextContent",
    "cloneInPlace",
    "queueAsyncEdit",
    "bringIntoView",
]

# Match the member accessed three ways:
#   1. dot access            x.member
#   2. bracket access        x["member"] / x['member']
#   3. object destructuring  const { member } = x   (and { a, member }, { member: y }, defaults)
# Form 3 catches reads that have no `.member` token.
# The destructuring alt is a lookahead so multiple destructured members on one
# line each match independently. It requires a `} =` after the member so plain
# object *literals* (e.g. `x = { member: 1 }`, `f({ member: 1 })`) don't match.
_PATTERNS = {
    m: re.compile(
        r"\.\s*" + re.escape(m) + r"\b"                        # x.member
        r"|\[\s*['\"]" + re.escape(m) + r"['\"]\s*\]"          # x["member"]
        r"|[{,]\s*" + re.escape(m) + r"\b(?=[^{}]*\}\s*=)"     # const { member } = x
    )
    for m in UNSAFE_MEMBERS
}

# A file is treated as minified if it has very few lines or an extremely long line.
def _is_minified(src: str) -> bool:
    lines = src.split("\n")
    if len(lines) <= 2:
        return True
    return any(len(ln) > 5000 for ln in lines)


def _line_of(src: str, pos: int) -> int:
    return src.count("\n", 0, pos) + 1


def _sample(src: str, start: int, end: int, pad: int = 40) -> str:
    snippet = src[max(0, start - pad): end + pad]
    return re.sub(r"\s+", " ", snippet).strip()


def detect_file(path: str) -> dict:
    """Scan one JS file. Returns a structured, deterministic result."""
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            src = f.read()
    except OSError as e:
        return {"file": path, "error": str(e), "named_api_hit": False, "apis": {}}

    minified = _is_minified(src)
    apis = {}
    for member, pat in _PATTERNS.items():
        hits = list(pat.finditer(src))
        if not hits:
            continue
        entry = {"count": len(hits)}
        if minified:
            # Line numbers are meaningless on minified code — give evidence snippets instead.
            entry["samples"] = [_sample(src, m.start(), m.end()) for m in hits[:5]]
        else:
            entry["lines"] = sorted({_line_of(src, m.start()) for m in hits})
        apis[member] = entry

    return {
        "file": path,
        "minified": minified,
        "named_api_hit": bool(apis),
        "apis": apis,
    }


def _package_dir(manifest_path: str) -> str:
    """The add-on package folder (parent of dist/ if the manifest sits in dist/)."""
    manifest_dir = os.path.dirname(manifest_path)
    if os.path.basename(manifest_dir) == "dist":
        return os.path.dirname(manifest_dir)
    return manifest_dir


def _addon_id(package_dir: str) -> str:
    """Add-on id = package folder name up to the first hyphen."""
    return os.path.basename(package_dir.rstrip(os.sep)).split("-", 1)[0]


def _find_document_sandbox(manifest: dict):
    """Return the documentSandbox path (relative to the manifest dir), or None."""
    for entry in manifest.get("entryPoints", []) or []:
        if isinstance(entry, dict):
            # Current field name, with a fallback to the legacy "script" field.
            val = entry.get("documentSandbox") or entry.get("script")
            if val:
                return val
    return None


def _find_manifest(package_dir: str):
    """Locate manifest.json for a single package: prefer dist/manifest.json, else the dir's own."""
    candidates = [
        os.path.join(package_dir, "dist", "manifest.json"),
        os.path.join(package_dir, "manifest.json"),
    ]
    for c in candidates:
        if os.path.isfile(c):
            return c
    return None


def detect_package(package_dir: str) -> dict:
    """Analyze a single add-on package directory."""
    package_dir = os.path.abspath(package_dir)
    rec = {
        "packageDir": package_dir,
        "addonId": _addon_id(package_dir),
    }

    if not os.path.isdir(package_dir):
        rec.update({"error": "not a directory", "hasSandbox": False})
        return rec

    manifest_path = _find_manifest(package_dir)
    if not manifest_path:
        rec.update({"error": "no manifest.json found (looked in ./ and ./dist/)", "hasSandbox": False})
        return rec

    rec["manifest"] = manifest_path
    try:
        with open(manifest_path, "r", encoding="utf-8", errors="replace") as f:
            manifest = json.load(f)
    except (OSError, ValueError) as e:
        rec.update({"error": "unreadable manifest: %s" % e, "hasSandbox": False})
        return rec

    rec["addonName"] = manifest.get("name", "")
    ds = _find_document_sandbox(manifest)
    if not ds:
        rec["hasSandbox"] = False
        return rec

    sandbox_path = os.path.join(os.path.dirname(manifest_path), ds)
    rec["hasSandbox"] = True
    rec["documentSandbox"] = ds
    rec["sandboxPath"] = sandbox_path
    rec["detect"] = detect_file(sandbox_path)
    return rec


def main(argv):
    if len(argv) != 3 or argv[1] not in ("file", "package"):
        sys.stderr.write(
            "usage:\n"
            "  python3 detect_unsafe_apis.py file <sandbox_js_path>\n"
            "  python3 detect_unsafe_apis.py package <packageDir>\n"
        )
        return 2
    mode, target = argv[1], argv[2]
    result = detect_file(target) if mode == "file" else detect_package(target)
    json.dump(result, sys.stdout, indent=2)
    sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
