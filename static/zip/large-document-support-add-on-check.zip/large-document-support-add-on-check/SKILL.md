---
name: large-document-support-add-on-check
version: 2.0.0
description: |
  Checks a single Adobe Express add-on package for usage of the express-document-sdk
  APIs that are deprecated under Large Document Support, plus unsafe node-reference
  patterns (references held across an async boundary, persisted between exposed-API
  calls, or leaked out of a "safe" API callback — all of which throw "Stale node
  reference" at runtime), then reports an advisory assessment and the reason directly
  in chat. Uses a hybrid engine: a deterministic script (detect_unsafe_apis.py) finds
  direct use of a fixed set of affected express-document-sdk APIs (allChildren,
  artboards, allDescendants, allTextContent, cloneInPlace, queueAsyncEdit,
  bringIntoView), and inline analysis catches the general anti-pattern of holding a
  node reference past the synchronous block where it was obtained. Never reads whole
  minified bundles into context.
allowed-tools:
  - Bash
  - Read
  - Grep
---

# Large Document Support add-on check

> **What this is — and what it isn't.** This is a **self-assessment starting point** that
> helps you decide whether your Adobe Express add-on is likely affected by
> [Large Document Support](https://developer.adobe.com/express/add-ons/docs/guides/learn/platform-concepts/large-document-support/).
> It is **not** an official ruling, and it has **no** bearing on any marketplace review or
> enforcement decision. It errs toward caution, so it can report both false positives and
> false negatives. Whatever it reports, **always validate your add-on in the Large Document
> Support testing environment** before you rely on the result.

This skill checks **one Adobe Express add-on package** at a time for node-safety problems: a
`Node` reference held past the synchronous block where it was obtained throws a
`"Stale node reference"` error at runtime once the active page changes. It highlights add-ons
whose code **will throw** on such patterns, plus direct use of a fixed set of
`express-document-sdk` APIs that are deprecated under Large Document Support. It checks one
add-on and reports the result in chat.

## Hybrid detection model
- **Deterministic** — `detect_unsafe_apis.py` finds direct use of the named affected
  APIs (below). Reproducible, line-cited, runs outside the context window. Any genuine
  hit ⇒ the add-on is likely impacted.
- **Inline analysis** — you catch held / leaked / stale node references (across async
  gaps incl. UI-iframe proxy calls, between calls, or outside a safe-API callback).
  Bias toward recall.
- `assessment_score = max(deterministic, inline)`; the practical reading is **`> 0` ⇒
  likely impacted — review it and test**. The score (0–3) is a rough severity hint only. It
  is advisory, not a pass/fail decision.

**Named affected APIs:** `allChildren`, `artboards`, `allDescendants`,
`allTextContent`, `cloneInPlace`, `queueAsyncEdit`, `bringIntoView`.
(Stale-reference patterns in `node-reference-examples.md`.)

## Bundled files
| File | Role |
|---|---|
| `detect_unsafe_apis.py` | Deterministic named-affected-API detector (`file` and `package` modes). |
| `node-reference-examples.md` | Canonical unsafe/safe stale-reference examples — read once before analysing. |

Let `{skillDir}` = the absolute path of this skill's folder (where this file is).

## Golden rule — protect your context
**Never `Read` a whole minified/large sandbox bundle into context.** These files can
be enormous; ingesting them destroys accuracy. Instead:
- Use `detect_unsafe_apis.py` (returns only compact hits).
- Use scoped `rg -o '.{0,80}<pattern>.{0,80}' <file>` to pull *excerpts*.
- Only `Read` a file directly if it is small and non-minified (≲ 1500 lines and not a
  single giant line). Otherwise, work exclusively from script + `rg` output.

---

## Step 1 — Select the add-on and run the deterministic scan

Ask the user, in plain text:

> "Please enter the full path to the **add-on package directory** to check.
> (Example: `/Users/you/my-add-on`)"

Use the reply as `{packageDir}`. Then run the package scan (finds the manifest,
identifies the add-on, and runs the named-API detector in one context-free pass):

```bash
python3 {skillDir}/detect_unsafe_apis.py package "{packageDir}"
```

This prints JSON with: `packageDir`, `addonId`, `addonName`, `hasSandbox`, and — if a
document sandbox exists — `sandboxPath` and the deterministic `detect` result.

- If it reports an **error** (not a directory, or no `manifest.json`), tell the user
  this is not a checkable add-on package and stop.
- If `hasSandbox` is **false** → **UI-only add-on**. Set `assessment_score = 0` and
  `reason` = the constant string:
  `No documentSandbox entrypoint — UI-only add-on, out of scope for node-reference analysis`,
  then go to **Step 5**.
- Otherwise continue with `sandboxPath` and the `detect` result.

---

## Step 2 — Deterministic result (named APIs)

Read `detect.named_api_hit` and `detect.apis` from the Step 1 output (the script
already scanned the sandbox — do not re-read the bundle). If `named_api_hit` is true,
the add-on is **likely impacted**: record the exact APIs and their lines (or samples, if
minified) for the reason. This alone sets a floor of `assessment_score = 3`.

---

## Step 3 — Inline analysis: held / leaked / stale references

Beyond the named APIs, look for the general "operating on a node whose page is no
longer active" risk and misuse of the safe APIs. First read
`{skillDir}/node-reference-examples.md` **once** (the canonical 6 unsafe / 3 safe
examples). Then surface candidates with scoped searches against `{sandboxPath}`:

```bash
# reference origins
rg -o '.{0,60}(editor\.context\.(selection|insertionParent|currentPage)|documentRoot|\.pages\b|editor\.create\w+\(|\.addPage\().{0,60}' "{sandboxPath}" | head -40
# async boundaries (incl. UI-iframe proxy calls) and safe APIs
rg -o '.{0,80}(await |\.then\(|setTimeout|setInterval|new Promise|Proxy|apiProxy|queueAsyncEdit|keepContentActiveDuringAsync|visitPages).{0,80}' "{sandboxPath}" | head -40
```

Note (per `node-reference-examples.md`) when a node reference is:
- **held across an async boundary** — captured, then read/mutated after an `await` /
  `.then` / timer / awaited UI-proxy call (reads throw too);
- **persisted between exposed-API calls** — stored in a module/object/collection and
  used in a later call;
- **used unsafely despite a safe API** — captured before the gap and used after instead
  of derived fresh inside the callback, or stored and used **outside** a `visitPages` /
  `keepContentActiveDuringAsync` callback.

**Bias toward recall:** when you cannot confirm a reference is safe (common in minified
code), treat it as a signal. Presence of a "safe" API does **not** clear the add-on.

---

## Step 4 — Score

`assessment_score` = the **max** of:
- deterministic floor: `3` if `named_api_hit`, else `0`;
- inline finding: `3` for a confirmed held/leaked/stale reference, `1` if only
  suspected (uncertain / minified / cannot confirm), else `0`.

The practical reading is: **`> 0` ⇒ the add-on likely needs updating — review it and test
it in the Large Document Support environment.** This is an advisory signal, not a pass/fail
decision. Only score `0` when you are confident there are no named-API calls and no held
references — and even then, testing is the real confirmation.

---

## Step 5 — Report in chat

Tell the user, in chat:
- **`addon_id`** and **`addon_name`** (from Step 1).
- **`assessment_score`** (0–3) and whether the add-on is **likely impacted (`> 0`)** or
  shows no signals (`0`).
- **`reason`** — one or two sentences. If likely impacted: name the deterministic APIs +
  lines and/or the held-reference pattern and page context (e.g. "calls `cloneInPlace`
  (line 12) and `queueAsyncEdit` (line 13); also holds the selected node across an
  `await`"). If no signals: state why (e.g. "only synchronous edits to
  `editor.context.selection`; no named affected APIs, no references held across async
  gaps or between calls"). For UI-only, use the constant string from Step 1.
- **A reminder** that this is a starting point: whatever the result, validate the add-on in
  the Large Document Support testing environment before relying on it.

Do not write any files — the chat report is the deliverable.

---

## Determinism notes
- **Deterministic and reproducible:** manifest discovery and the named-API scan
  (`detect_unsafe_apis.py`). A named-API hit is identical on every run and cited by line.
- **Non-deterministic:** the held/leaked-reference judgment. Variance lives only on the
  genuinely undecidable part; it can only *add* signals on top of the deterministic floor,
  never remove one.
