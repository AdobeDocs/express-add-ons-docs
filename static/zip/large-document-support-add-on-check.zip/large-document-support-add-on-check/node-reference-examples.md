# Node Reference Examples

When an add-on holds onto a `Node` object and the active page later changes, that
node becomes **stale**. Any subsequent access to it throws a `"Stale node reference"`
error.

This document shows **6 examples of unsafe stale usage** and **3 examples of the correct patterns**.

---

## How a node becomes stale

| Pattern | How staleness occurs |
|---|---|
| **A — async gap** | The add-on `await`s a sandbox API or a UI iframe proxy call. While execution is suspended, the user navigates to a different page. When execution resumes, any node captured before the `await` is stale. |
| **B — persisted reference** | A node reference is stored in a module-level variable across separate function invocations. The node is valid during the first call, but if the user navigates to a different page between calls, the stored reference is stale by the time the second call reuses it. |

---

## Stale node reference examples (will throw)

### Pattern A — Async gap (user navigates during `await`)

In these examples the node is valid at the point of capture, but the user navigates to a different page
while the add-on is suspended at an `await`. When execution resumes the original page is no longer active.

---

#### Example 1: `await editor.loadBitmapImage()` then read a captured node

```typescript
import { editor } from "express-document-sdk";

// Capture a node from selection, await image loading, then try to read the captured node
async function stale_readNodeAfterLoadBitmapImage(imageBlob: Blob) {
    const node = editor.context.selection[0];

    // ⚠️ Some async operation — user navigates to another page during this await
    const bitmapImage = await editor.loadBitmapImage(imageBlob);

    // ❌ THROWS: reading any property on a stale node throws
    const pos = node.translation;
    console.log("Current position:", pos);
}
```

**Fix:** Wrap with `editor.keepContentActiveDuringAsync(node, async () => { ... }, callback)` to keep the node's page active across the async gap.

---

#### Example 2: `await panelUIProxy.delay()` (UI iframe call) then read a captured node

```typescript
import { editor } from "express-document-sdk";
import type { RectangleNode } from "express-document-sdk";

// Capture a node from selection, await a UI proxy delay, then try to read the captured node
async function stale_readNodeAfterUiProxyDelay(
    panelUIProxy: { delay(ms: number): Promise<void> }
) {
    const rect = editor.context.selection[0] as RectangleNode;

    // ⚠️ UI iframe proxy call — crosses the iframe boundary, can take arbitrary time
    // User navigates to another page during the delay
    await panelUIProxy.delay(3000);

    // ❌ THROWS: reading any property on a stale node throws
    console.log("Width:", rect.width, "Position:", rect.translation);
}
```

**Why this matters:** Any call to a UI iframe API proxy (`panelUIProxy.*`) is an async boundary, even if it
feels instantaneous. The user is free to navigate pages while the sandbox is awaiting a UI call.

---

#### Example 3: `await panelUIProxy.translateText()` then read the text node

```typescript
import { editor } from "express-document-sdk";
import type { TextNode } from "express-document-sdk";

// Capture a text node, await a network translation call, then try to read the captured node
async function stale_readNodeAfterTranslationCall(
    panelUIProxy: { translateText(s: string): Promise<string> }
) {
    const textNode = editor.context.selection[0] as TextNode;
    const originalText = textNode.fullContent.text;

    // ⚠️ Network call via UI iframe — user can navigate during the translation request
    const translatedText = await panelUIProxy.translateText(originalText);

    // ❌ THROWS: reading any property on a stale node throws
    console.log("Original was:", textNode.fullContent.text);
}
```

**Fix:** Use `keepContentActiveDuringAsync(textNode, async () => panelUIProxy.translateText(...), result => { textNode.fullContent.text = result; })` to both keep the page active and safely apply the write in the after-callback.

---

#### Example 4: `queueAsyncEdit` with a captured stale node (write)

Document edits after an `await` must be scheduled with `queueAsyncEdit` (or `keepContentActiveDuringAsync`).
That does **not** make a captured node reference safe — the stale guard still runs when the lambda
touches the old node.

```typescript
import { editor } from "express-document-sdk";

// Capture a node, await a UI call, then schedule an edit on the captured node
async function stale_queueAsyncEditWithCapturedNode(
    panelUIProxy: { delay(ms: number): Promise<void> }
) {
    const node = editor.context.selection[0];

    // User navigates to another page during this await
    await panelUIProxy.delay(3000);

    // queueAsyncEdit is required for writes after await — but node is still stale
    await editor.queueAsyncEdit(() => {
        // ❌ THROWS: stale guard runs when the lambda accesses node
        node.translation = { x: 50, y: 50 };
    });
}
```

**Fix:** Use `keepContentActiveDuringAsync(node, async () => { ... }, () => { node.translation = ... })` instead of holding `node` across the gap with `queueAsyncEdit`.

---

#### Example 5: `queueAsyncEdit` with a captured stale node (read)

Reads after `await` are allowed without `queueAsyncEdit`, but they still throw if the node is stale.
Using `queueAsyncEdit` does not bypass the stale check (this example uses `queueAsyncEdit` only to show
that wrapping a read in a queued lambda does not help).

```typescript
import { editor } from "express-document-sdk";
import type { TextNode } from "express-document-sdk";

async function stale_queueAsyncEditReadCapturedNode(
    panelUIProxy: { translateText(s: string): Promise<string> }
) {
    const textNode = editor.context.selection[0] as TextNode;
    const originalText = textNode.fullContent.text;

    await panelUIProxy.translateText(originalText);

    await editor.queueAsyncEdit(() => {
        // ❌ THROWS: reading textNode.fullContent.text still hits the stale guard
        console.log("Text was:", textNode.fullContent.text);
    });
}
```

---

### Pattern B — Persisted reference across invocations

These examples store a node in a module-level variable during one function call and reuse it in a later
call. The node is valid at creation time, but becomes stale if the user navigates to a different page
between invocations.

---

#### Example 6: Reusing a module-level node reference across button clicks

```typescript
import { editor } from "express-document-sdk";
import type { RectangleNode } from "express-document-sdk";

// Module-level variable — persists across add-on button clicks
let holdRectangleReference: RectangleNode | undefined;

// Called each time the user clicks a button in the add-on
function stale_reusePersistedRectangleReference() {
    if (!holdRectangleReference) {
        // First call: create a rectangle on the current page and store the reference
        const rect = editor.createRectangle();
        editor.context.insertionParent.children.append(rect);
        holdRectangleReference = rect; // ⚠️ stored for reuse
    } else {
        // Second call: user has navigated to another page between clicks
        // ❌ THROWS: reading holdRectangleReference.id hits the stale guard
        console.log("holdRectangleReference: " + holdRectangleReference.id);
    }
}
```

**Why:** `holdRectangleReference` is assigned while a page is active. If the user navigates away
before clicking the button again, that page is no longer active and `holdRectangleReference` becomes stale.

---

## Correct usage examples (will not throw)

### Example A: Create and configure a node synchronously

```typescript
import { editor, colorUtils } from "express-document-sdk";

// Create a rectangle and add it to the current page — all synchronous, no stale risk
function safe_createAndAppendRectangle() {
    const rect = editor.createRectangle();
    rect.width = 200;
    rect.height = 150;
    rect.translation = { x: 100, y: 100 };
    rect.fill = editor.makeColorFill(colorUtils.fromRGB(0.25, 0.5, 0.75, 1));

    editor.context.insertionParent.children.append(rect);
}
```

**Why it is safe:** No `await`, no page navigation. The node lives on the currently active page for the
entire lifetime of the synchronous function.

---

### Example B: Use `keepContentActiveDuringAsync` to safely edit after an await

```typescript
import { editor } from "express-document-sdk";
import type { TextNode } from "express-document-sdk";

// Translate a text node's content using a UI proxy call — safely pinning the node across the async gap
async function safe_translateTextWithKeepContentActive(
    panelUIProxy: { translateText(s: string): Promise<string> }
) {
    const textNode = editor.context.selection[0] as TextNode;
    const originalText = textNode.fullContent.text;

    // ✅ keepContentActiveDuringAsync pins the page in memory across the async gap
    await editor.keepContentActiveDuringAsync(
        textNode,
        async () => {
            // All async work runs here — safe to await UI proxy calls or network requests
            return await panelUIProxy.translateText(originalText);
        },
        (translatedText) => {
            // This callback is guaranteed to run while the node's page is still active
            textNode.fullContent.text = translatedText;
        }
    );
}
```

**Why it is safe:** `keepContentActiveDuringAsync` keeps the node's page loaded for the
duration of the async lambda. The edit callback runs synchronously after the async work completes with
the page still guaranteed active.

---

### Example C: Use `visitPages` to safely iterate and edit all pages

```typescript
import { editor } from "express-document-sdk";
import type { TextNode } from "express-document-sdk";

// Rename text nodes in all pages using a translation service — each page is safely active during its own callback
async function safe_renameAllPagesWithVisitPages(
    panelUIProxy: { translateText(s: string): Promise<string> }
) {
    const pages = editor.documentRoot.pages;

    // ✅ visitPages activates each page in turn and keeps it active for the full callback
    await pages.visitPages([...pages], async (page) => {
        // Assume the first child is a text node for now
        const textNode = page.artboards.first!.children.item(0) as TextNode;
        const translated = await panelUIProxy.translateText(textNode.fullContent.text);
        textNode.fullContent.text = translated;
    });
}
```

**Why it is safe:** `visitPages` controls the page lifecycle. Each page is kept active until its callback
promise resolves. Nodes accessed within a page's callback are always on the active page. Edits after
`await` inside the callback are allowed without `queueAsyncEdit` because `visitPages` keeps that page
active until the async callback finishes. Never store those node references and use them outside the callback.
