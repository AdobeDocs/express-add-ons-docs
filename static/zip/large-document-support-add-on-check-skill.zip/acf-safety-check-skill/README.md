# ACF Safety Check

A lightweight checker that tells you whether your **Adobe Express add-on** will
break under the **Active Content Facade (ACF)** — and how to fix it — by
analyzing your **source code** directly. No build step, no minified bundles, no
guessing.

## Why this exists

Under ACF, only the page the user is currently viewing is **active**. Pages that
scroll out of view become **inactive**, and any `Node` reference into an inactive
page throws `"Stale node reference"` the next time you touch it. Add-ons written
before ACF often:

- call `queueAsyncEdit` (removed under ACF),
- hold a node reference across an `await` (the user can navigate during the wait),
- stash a node in a module-level variable and reuse it on a later call, or
- traverse into non-active pages (`pages.first.allChildren`, …).

This tool finds those spots in your `src/` and shows the ACF-safe rewrite.

## Requirements

- **Node.js 18+** (you already have it — it's the Express add-on toolchain).
- Network access on the **first** run only (see below).
- **Your add-on's own dependencies must be current** — run `npm update` from
  your add-on's folder before checking/fixing. The fixes this tool recommends
  (`keepContentActiveDuringAsync`, `visitPages`, etc.) only typecheck if your
  `express-document-sdk` type definitions are up to date; a stale install can
  make a correct fix look like a type error.

There is **no Python** and no separate runtime — everything runs on Node.

## Setup — none

There is no `npm install` step. The one dependency the engine needs (`ts-morph`,
which pulls in `typescript`) is fetched **on demand** the first time you run the
checker, into a cache dir (`~/.cache/acf-safety-check-skill`, override with
`ACF_CHECK_DEPS_DIR`). The first run prints a one-time fetch line and needs
Node.js/npm on PATH plus network access; every run after that is offline.

Verify it's working:

```bash
node scripts/eval-check.js   # runs the fixture regression suite
```

## Usage

Point it at your add-on folder, its `src/` folder, or a single file:

```bash
# whole add-on (finds src/manifest.json, scans the sandbox source)
node scripts/check-acf.js /path/to/my-add-on

# just the source folder
node scripts/check-acf.js /path/to/my-add-on/src

# a single sandbox file
node scripts/check-acf.js /path/to/my-add-on/src/sandbox/code.ts
```

Example output:

```
✗ ACF issues found: 1 error(s), 0 warning(s) across 3 file(s).

  [ERROR] src/sandbox/code.ts:42  (patternA) `textNode`
         Why: A node reference captured before an await is used after it...
         Fix: Wrap the async work in editor.keepContentActiveDuringAsync(...)...
         See: references/safe-patterns.md#pattern-a-async-gap
```

### Options

| Flag | Effect |
|---|---|
| `--json` | Emit the full result as JSON to stdout (for tooling / editors). |
| `--report <dir>` | Also write `acf-report.json` and `acf-report.md` into `<dir>`. |
| `--help` | Show usage. |

### Exit codes (for CI / pre-commit)

| Code | Meaning |
|---|---|
| `0` | Safe — no ACF errors (may include warnings to review). |
| `1` | One or more ACF **errors** found. |
| `2` | Usage or setup error (e.g. `ts-morph` not installed). |

Gate a pipeline or git hook on it:

```bash
node scripts/check-acf.js ./src   # non-zero fails the build
```

## What it reports

| Rule | Severity | Meaning |
|---|---|---|
| `tier1_queueAsyncEdit` | error | `queueAsyncEdit` is removed under ACF. |
| `tier2_hazard` | error | A context API (`allChildren`, `artboards`, …) on a provably non-active page. |
| `tier2_unknown` | warning | A context API where the checker couldn't prove the receiver is the active page — verify it. |
| `patternA` | error | Node captured before an `await`, used after it. |
| `patternB` | error | Node stored at module scope, reused in a later call. |

UI-only add-ons (no `documentSandbox` entry point) are reported as out of scope.

Every finding points to a section in
[`references/safe-patterns.md`](references/safe-patterns.md) with a
**before → after** fix.

## How it works

`scripts/check-acf.js` gathers your `.ts`/`.js` source (skipping `node_modules`,
`dist`, build output), and `scripts/acf-core.js` parses it with
[`ts-morph`](https://ts-morph.com). Using real symbol resolution it:

1. traces the `express-document-sdk` / `add-on-sdk-document-sandbox` import
   through your variables,
2. flags Tier 1/Tier 2 named APIs, using type-flow to **clear** the ones proven
   to be on the active page (so you don't get false alarms on safe code), and
3. tracks node references across `await` boundaries (Pattern A) and module scope
   (Pattern B).

Because it reads your **source**, results are precise (real names and types) and
there's nothing to de-minify.

> Auditing a *shipped / zipped* add-on bundle instead of source? That's a
> different job (de-minification, sourcemap recovery) handled by the review
> team's `acf-hlapi-add-on-audit-skill`. This skill is for developers working in
> their own source tree.

## Running via Claude Code / Copilot

`SKILL.md` wraps this CLI as an agent skill: it runs the checker, does a manual
verification pass over the scanned source to catch shapes the deterministic
engine can't yet resolve (that pass can only add findings, never remove one the
checker reported), explains each finding in plain language, shows the matching
safe-pattern rewrite, and can apply the fixes to your source on request.
Trigger it by asking to "check my add-on for ACF safety."

## Development

- `node scripts/eval-check.js` runs the fixture regression gate against
  `scripts/fixtures/`. Run it after any change to `scripts/acf-core.js` or
  `scripts/check-acf.js`.
- Add a fixture + a `scripts/fixtures/manifest.json` entry whenever you add or
  change a detection rule.
