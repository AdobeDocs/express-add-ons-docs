// On-demand dependency bootstrap for the AST engine.
//
// acf-core.js needs ts-morph (which pulls in typescript) at runtime. Rather
// than shipping a package.json / node_modules and asking developers to run
// `npm install`, we fetch those packages on demand into a shared cache
// directory the first time the checker runs, then load them from there. This
// keeps the skill shippable as plain scripts with no dependency-management
// step. Override the cache location with ACF_CHECK_DEPS_DIR; otherwise it lives
// under $XDG_CACHE_HOME (or ~/.cache) so a read-only skill install still works.

const { execFileSync } = require("child_process");
const fs = require("fs");
const os = require("os");
const path = require("path");

const TS_MORPH_SPEC = "ts-morph@^28.0.0";
const TYPESCRIPT_SPEC = "typescript@^5.5.4";

let _cached; // undefined = not tried yet, null = failed, object = ts-morph module
let loadError = null;

function depsDir() {
    const override = process.env.ACF_CHECK_DEPS_DIR;
    if (override) return path.resolve(override);
    const cacheRoot = process.env.XDG_CACHE_HOME || path.join(os.homedir(), ".cache");
    return path.join(cacheRoot, "acf-safety-check-skill");
}

function tsMorphInstalled(dir) {
    return fs.existsSync(path.join(dir, "node_modules", "ts-morph", "package.json"));
}

function requireFrom(nodeModulesDir) {
    try {
        // Resolve ts-morph from the given node_modules; its own transitive
        // requires (typescript, @ts-morph/common, …) then resolve relative to
        // ts-morph's location in that same tree.
        const entry = require.resolve("ts-morph", { paths: [nodeModulesDir] });
        return require(entry);
    } catch (e) {
        return null;
    }
}

// Returns the ts-morph module, or null if it could not be loaded/installed.
// Never throws — callers degrade to a clear setup error.
function loadTsMorph() {
    if (_cached !== undefined) return _cached;

    const dir = depsDir();
    const nodeModules = path.join(dir, "node_modules");

    // 1. Already cached from a previous run.
    if (tsMorphInstalled(dir)) {
        _cached = requireFrom(nodeModules);
        if (_cached) return _cached;
    }

    // 2. Ambient (e.g. a dev checkout that happens to have it resolvable).
    try {
        _cached = require("ts-morph");
        return _cached;
    } catch (e) {
        // fall through to install
    }

    // 3. Install on demand into the cache dir.
    const npm = process.platform === "win32" ? "npm.cmd" : "npm";
    try {
        fs.mkdirSync(dir, { recursive: true });
        process.stderr.write(
            `acf-safety-check-skill: fetching AST dependencies (ts-morph, typescript) into ${dir} (first run only)...\n`
        );
        execFileSync(
            npm,
            ["install", "--no-save", "--no-package-lock", "--no-audit", "--no-fund", "--loglevel=error", "--prefix", dir, TS_MORPH_SPEC, TYPESCRIPT_SPEC],
            { stdio: ["ignore", "ignore", "inherit"] }
        );
    } catch (e) {
        loadError = `automatic install of ts-morph failed (${e.message}). Ensure Node.js/npm are on PATH and network access is available for the first run.`;
        _cached = null;
        return _cached;
    }

    _cached = requireFrom(nodeModules);
    if (!_cached) loadError = "ts-morph installed but could not be loaded from the cache directory.";
    return _cached;
}

module.exports = {
    loadTsMorph,
    get loadError() { return loadError; }
};
