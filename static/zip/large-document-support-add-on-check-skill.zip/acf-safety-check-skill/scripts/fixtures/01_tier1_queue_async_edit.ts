import { editor } from "express-document-sdk";

// Tier 1: queueAsyncEdit is removed under ACF — always flagged.
export function run() {
    editor.queueAsyncEdit(() => {
        editor.context.currentPage.name = "renamed";
    });
}
