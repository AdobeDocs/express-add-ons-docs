---
name: acf-safety-check-skill
description: |
  Checks a single Adobe Express add-on's own source code for Active Content
  Facade (ACF) safety and explains, in plain language, how to fix what it finds.
  Use when a developer wants to know whether their add-on will break under ACF,
  asks to "check ACF safety", "make my add-on ACF-compatible", or to review or
  fix document-sandbox code that holds a Node reference across an await or across
  calls, or uses queueAsyncEdit — even when they don't name ACF explicitly. Runs
  a deterministic Node checker over the add-on's src/ (no build step, no minified
  bundles), manually cross-checks the scanned source for anything the static
  analysis structurally can't prove, then turns each finding into an ACF-safe
  before/after rewrite and can apply the fixes on request. Not for batch-auditing
  a directory of many add-on packages or shipped/minified bundles — use
  acf-hlapi-add-on-audit-skill for that, and not for non-ACF lint or security
  review.
allowed-tools:
  - Bash
  - Read
  - Write
  - Edit
---

# ACF Safety Check — developer skill

Adobe Express is rolling out the **Active Content Facade (ACF)**: only the page
the user is currently viewing stays active; pages scrolled out of view become
**inactive**, and any `Node` reference to an inactive page throws
`"Stale node reference"` on the next access. Add-ons written before ACF that
hold node references across an `await`, reuse them across calls, or reach into
non-active pages **will break**. This skill finds those spots in the developer's
own **source** and shows how to fix them.

Let `{skillDir}` = the absolute path of this skill's folder (where this file is).

## What it checks
- **`queueAsyncEdit`** — removed under ACF (Tier 1).
- **Tier 2 context APIs** — `artboards`, `allChildren`, `allDescendants`,
  `allTextContent`, `cloneInPlace`, `bringIntoView` — unsafe unless the receiver
  is provably the active page. The checker clears the safe cases automatically.
- **Pattern A** — a node captured before an `await` and used after it.
- **Pattern B** — a node stored at module scope and reused in a later call.

UI-only add-ons (no `documentSandbox` entry point) are out of scope and reported
as safe.

## Bundled files
| File | Role |
|---|---|
| `scripts/check-acf.js` | Deterministic CLI checker. Scans source, prints findings, writes reports, exits non-zero on hazards. |
| `scripts/acf-core.js` | The ts-morph detection engine (Tier 1/2, TypeFlow, Pattern A/B). |
| `scripts/ensure-deps.js` | Fetches ts-morph on demand into a cache dir the first time the checker runs. |
| `references/safe-patterns.md` | Before/after ACF-safe fix recipes, one per rule. Open the section named by a finding's `ref` to show the developer the matching rewrite. |
| `scripts/fixtures/` + `scripts/eval-check.js` | Regression gate — run `node scripts/eval-check.js` after any change to `scripts/acf-core.js` or `scripts/check-acf.js`, before trusting a real run. |

## Dependencies (no install step)
The AST engine needs `ts-morph` (which pulls in `typescript`). These are fetched
**on demand** the first time `scripts/check-acf.js` runs — installed into a cache
dir (`~/.cache/acf-safety-check-skill`, override with `ACF_CHECK_DEPS_DIR`) and
loaded from there. There is **no** `package.json` or `node_modules` to manage and
no `npm install` step. The **first** run therefore needs Node.js/npm on PATH and
network access, and prints a one-time fetch line to stderr; later runs are
offline. If the fetch can't run, `scripts/check-acf.js` exits with a clear setup
error (exit code 2) — never hand-analyze the source as a substitute.

---

## Step 1 — Ensure the add-on's own type definitions are current

Tell the developer to update their add-on's own dependencies first, from their
add-on's folder (not this skill's folder):

```bash
cd <their-add-on-folder> && npm update
```

The fixes this skill recommends (`keepContentActiveDuringAsync`, `visitPages`,
etc.) only typecheck against a current `express-document-sdk`. Skip this only
if the developer confirms their dependencies are already up to date — otherwise
a correct fix can look like a type error simply because their installed types
predate the API.

## Step 2 — Locate the add-on

Ask the developer for the path to their add-on if not already given — the add-on
folder, its `src/` folder, or a single sandbox file all work. Call it
`{target}`.

## Step 3 — Run the checker

```bash
node {skillDir}/scripts/check-acf.js "{target}" --report "{target}/.acf"
```

This prints human-readable findings, and writes `acf-report.json` and
`acf-report.md` into `{target}/.acf`. Read the JSON to drive the rest of the
conversation.

Interpret the exit/output:
- **UI-only** — tell the developer it's out of scope for ACF node-reference
  analysis, and stop.
- **Anything else** (safe or not) — continue to Step 4. Even a clean run needs
  the manual pass below before you call it safe.

## Step 4 — Manual verification pass

The deterministic engine can only flag shapes it has type-tracing for; a
receiver it can't resolve, a call routed through an unfamiliar alias, or a
staleness pattern it doesn't model yet all fall outside it. This is the
add-on's own **source** (not a shipped bundle) — small enough to read directly.
Read the scanned file(s) from Step 3 and re-check them by hand against:
- the named ACF-unsafe APIs in **"What it checks"** above, and
- the held/leaked-reference shapes in `references/safe-patterns.md`
  (Pattern A: async gap, Pattern B: persisted reference).

For anything genuine you find that Step 3 didn't report, add it to the
findings list in the same shape (`severity`, `rule`, `file`, `line`, `why`,
`fix`, `ref`) and mark it `"source": "manual-review"`. This pass may only
**add** findings on top of the deterministic ones — never remove or downgrade
one the checker already reported.

If the merged list is still empty, tell the developer the add-on is ACF-safe
and stop. Otherwise continue to Step 5.

## Step 5 — Explain each finding

For each finding — deterministic or manual-review — tell the developer, in
plain language:
- **Where:** `file:line` and the API/variable involved.
- **Why it breaks under ACF:** use the finding's `why`.
- **How to fix it:** use the finding's `fix`, then open the section of
  `{skillDir}/references/safe-patterns.md` named by the finding's `ref` and show
  the matching **before → after** example adapted to their code.

Group related findings (e.g. several `queueAsyncEdit` calls) so the developer
sees the pattern, not just line noise.

## Step 6 — Offer to fix

Offer to apply the fixes. If the developer accepts, edit their source directly,
one finding at a time, following `references/safe-patterns.md`:
- Replace `queueAsyncEdit(...)` with `keepContentActiveDuringAsync(...)`.
- For Pattern A, pin the node with `keepContentActiveDuringAsync` **or** re-fetch
  it from `editor.context` after the await.
- For Pattern B, persist a stable id (not the node) and re-fetch each call.
- For Tier 2 hazards, traverse from `editor.context.currentPage` or wrap
  cross-page work in `pages.visitPages(...)`.

**Never nest a doc-mutating async SDK call inside `keepContentActiveDuringAsync`'s
`asyncLambda`** (e.g. `loadBitmapImage`, `createRendition`,
`replaceMediaWithEditedImage`); it throws there. Await it *before* calling
`keepContentActiveDuringAsync`, then do the actual edit in `afterAsyncCallback`.
See `references/safe-patterns.md#doc-mutating-async-apis-and-keepcontentactiveduringasync`.

These fixes are **context-dependent, not mechanical** — apply them as reviewed
edits the developer can inspect, preserving their surrounding logic. Never
blindly find-and-replace.

## Step 7 — Re-check

After applying fixes, re-run Step 3 **and** redo the Step 4 manual pass on
whatever changed — a manual-review finding won't disappear from a script
re-run on its own, since the checker never saw it as a hit in the first place.
Report the before/after counts. Repeat until clean or until the remaining items
genuinely need the developer's judgment (e.g. a warning where only they know
whether the receiver is the active page).

---

## CI usage

`scripts/check-acf.js` exits non-zero when it finds an error-level hazard, so
developers can gate a pipeline or pre-commit hook on it:

```bash
node {skillDir}/scripts/check-acf.js ./src
```

This gates on the **deterministic floor only** — a CI hook has no manual-review
pass. Treat it as a fast pre-filter, not a substitute for Step 4 in an
interactive session.

## Determinism note
- **Deterministic and reproducible:** `scripts/check-acf.js` /
  `scripts/acf-core.js` — the same source always yields the same findings,
  cited by line.
- **Non-deterministic (Step 4, quarantined from the engine):** the manual
  verification pass and the held/leaked-reference judgment it makes. It can
  only *add* findings on top of the deterministic floor, never remove one.
- The explanation (Step 5) and the applied fixes (Step 6) also involve
  judgment, and both are always shown to the developer for review.
