// Large Document Support detection engine (source-mode).
//
// This runs on a developer's *unbundled* source (.ts/.js), so all shipped-bundle
// machinery — sourcemap recovery, minification handling, webpack eval-devtool unwrapping,
// sibling-chunk discovery — has been removed. What remains is the pure
// detection logic: SDK import tracing, Tier 1/Tier 2 named-API detection,
// TypeFlow (to clear safe usages), and Pattern A/B stale-reference dataflow.
//
// Exposes analyze(files) so callers (check-large-document-support.js,
// eval-check.js) consume it programmatically instead of via argv/stdout.

let Project, SyntaxKind;
// ts-morph is fetched on demand (see ensure-deps.js) — no package.json /
// node_modules to install. If it can't be loaded, export a null engine so the
// CLI reports a clear setup error instead of crashing.
const ensureDeps = require("./ensure-deps.js");
const tsMorph = ensureDeps.loadTsMorph();
if (!tsMorph) {
    module.exports = { analyze: null, loadError: ensureDeps.loadError };
    return;
}
({ Project, SyntaxKind } = tsMorph);

const TIER_1 = ["queueAsyncEdit"];
const TIER_2 = ["artboards", "allDescendants", "allTextContent", "cloneInPlace", "allChildren", "bringIntoView"];
const ALL_MEMBERS = [...TIER_1, ...TIER_2];

const SDK_MODULES = new Set(["express-document-sdk", "add-on-sdk-document-sandbox"]);

/**
 * Analyze a set of source files for Large-Document-Support-unsafe patterns.
 * @param {{path: string, content: string}[]} files
 * @returns detection result object.
 */
function analyze(files) {
    const project = new Project({
        useInMemoryFileSystem: true,
        // Add-on source is often plain .js. Without allowJs, ts-morph's type
        // checker never binds symbols for JS identifiers — getSymbol() returns
        // undefined for every reference, so TypeFlow and Pattern A/B silently
        // never fire. checkJs off keeps type-error noise out.
        compilerOptions: { allowJs: true, checkJs: false }
    });

    files.forEach(f => project.createSourceFile(f.path, f.content, { overwrite: true }));

    // ---- SDK alias discovery (import / require / dynamic import) ----
    const sdkAliases = new Set();
    let hasSdk = false;

    project.getSourceFiles().forEach(sourceFile => {
        sourceFile.getImportDeclarations().forEach(imp => {
            if (SDK_MODULES.has(imp.getModuleSpecifierValue())) {
                hasSdk = true;
                const def = imp.getDefaultImport();
                if (def) sdkAliases.add(def.getText());
                const ns = imp.getNamespaceImport();
                if (ns) sdkAliases.add(ns.getText());
                imp.getNamedImports().forEach(named => {
                    sdkAliases.add(named.getAliasNode() ? named.getAliasNode().getText() : named.getName());
                });
            }
        });

        sourceFile.getDescendantsOfKind(SyntaxKind.CallExpression).forEach(callExpr => {
            const args = callExpr.getArguments();
            if (args.length > 0 && args[0].getKind() === SyntaxKind.StringLiteral && SDK_MODULES.has(args[0].getLiteralText())) {
                hasSdk = true;
                const parent = callExpr.getParentIfKind(SyntaxKind.VariableDeclaration);
                if (parent) {
                    const nameNode = parent.getNameNode();
                    if (nameNode.getKind() === SyntaxKind.Identifier) {
                        sdkAliases.add(nameNode.getText());
                    } else if (nameNode.getKind() === SyntaxKind.ObjectBindingPattern) {
                        nameNode.getElements().forEach(el => sdkAliases.add(el.getNameNode().getText()));
                    }
                }
            }
        });
    });

    if (!hasSdk) {
        return { hasSdk: false, named_api_hit: false, tier1_hit: false, tier2_hit: false, apis: {}, patternA_hits: [], patternB_hits: [], skipped_no_sdk: true };
    }

    // Resolves an identifier to its binding declaration via the TS symbol
    // table (not string-name scope walking), so a function-local shadow of a
    // module var resolves to the shadowing decl, not the outer one.
    function getScopeDecl(node) {
        let symbol = node.getSymbol();
        if (!symbol) {
            try { symbol = project.getTypeChecker().getSymbolAtLocation(node); } catch (e) { symbol = undefined; }
        }
        if (!symbol) return null;
        const decls = symbol.getDeclarations();
        if (!decls || decls.length === 0) return null;
        return decls.find(d => d.getKind() === SyntaxKind.VariableDeclaration
            || d.getKind() === SyntaxKind.Parameter
            || d.getKind() === SyntaxKind.BindingElement) || decls[0];
    }

    // ---- TypeFlow: infer the Large-Document-Support-relevant "shape" of an expression ----
    function inferType(expr, visited = new Set(), depth = 0) {
        if (!expr || depth > 10) return "Unknown";
        if (visited.has(expr)) return "Unknown";
        visited.add(expr);

        const kind = expr.getKind();

        if (kind === SyntaxKind.Identifier) {
            const symbol = expr.getSymbol() || project.getTypeChecker().getSymbolAtLocation(expr);
            if (symbol) {
                const decls = symbol.getDeclarations();
                if (decls && decls.length > 0) {
                    let inferred = "Unknown";
                    for (const decl of decls) {
                        if (decl.getKind() === SyntaxKind.VariableDeclaration) {
                            const init = decl.getInitializer();
                            if (init) {
                                const t = inferType(init, visited, depth + 1);
                                if (t !== "Unknown") inferred = t;
                            } else {
                                // `for (const page of doc.pages)` — the loop
                                // variable's own declaration has no `=`
                                // initializer, so trace out to the
                                // ForOfStatement's iterable instead.
                                const declList = decl.getParentIfKind(SyntaxKind.VariableDeclarationList);
                                const forOf = declList && declList.getParentIfKind(SyntaxKind.ForOfStatement);
                                if (forOf) {
                                    const iterType = inferType(forOf.getExpression(), visited, depth + 1);
                                    if (iterType === "PageList") inferred = "PageNode";
                                    if (iterType === "NodeList") inferred = "SafeContainer";
                                }
                            }
                        } else if (decl.getKind() === SyntaxKind.Parameter) {
                            const parent = decl.getParent();
                            if (parent.getKind() === SyntaxKind.ArrowFunction || parent.getKind() === SyntaxKind.FunctionExpression) {
                                const callExpr = parent.getParentIfKind(SyntaxKind.CallExpression);
                                if (callExpr) {
                                    const propAccess = callExpr.getExpressionIfKind(SyntaxKind.PropertyAccessExpression);
                                    if (propAccess) {
                                        const methodName = propAccess.getName();
                                        const baseType = inferType(propAccess.getExpression(), visited, depth + 1);
                                        if (methodName === "visitPages") inferred = "ActivePageNode";
                                        else if (methodName === "forEach" || methodName === "map") {
                                            if (baseType === "PageList") inferred = "PageNode";
                                            else if (baseType === "NodeList") inferred = "SafeContainer";
                                        }
                                    }
                                }
                            } else if (parent.getKind() === SyntaxKind.FunctionDeclaration || parent.getKind() === SyntaxKind.MethodDeclaration) {
                                const paramIndex = parent.getParameters().indexOf(decl);
                                const nameNode = parent.getNameNode();
                                if (nameNode) {
                                    const refs = nameNode.findReferencesAsNodes();
                                    for (const ref of refs) {
                                        const callExpr = ref.getParentIfKind(SyntaxKind.CallExpression);
                                        if (callExpr && callExpr.getExpression() === ref) {
                                            const arg = callExpr.getArguments()[paramIndex];
                                            if (arg) {
                                                const argType = inferType(arg, new Set(visited), depth + 1);
                                                if (argType !== "Unknown") inferred = argType;
                                            }
                                        }
                                    }
                                }
                            }
                        } else if (decl.getKind() === SyntaxKind.BindingElement) {
                            const propName = decl.getPropertyNameNode() ? decl.getPropertyNameNode().getText() : decl.getNameNode().getText();
                            if (propName === "currentPage") inferred = "ActivePageNode";
                            else if (propName === "insertionParent") inferred = "SafeContainer";
                        }
                    }
                    if (inferred !== "Unknown") return inferred;
                }
            }
        } else if (kind === SyntaxKind.PropertyAccessExpression) {
            const name = expr.getName();
            const base = expr.getExpression();
            if (name === "currentPage") return "ActivePageNode";
            if (name === "insertionParent") return "SafeContainer";
            if (name === "parent") {
                const baseType = inferType(base, visited, depth + 1);
                if (baseType === "SafeContainer") return "ActivePageNode";
                if (baseType === "PageNode") return "Unknown";
            }
            if (name === "first" || name === "last") {
                const baseType = inferType(base, visited, depth + 1);
                if (baseType === "PageList") return "PageNode";
                if (baseType === "NodeList") return "SafeContainer";
                if (baseType === "InactiveNodeList") return "PageNode";
            }
            if (name === "pages") return "PageList";
            // editor.context.selection is a live list of Nodes on the active
            // page; indexed elements (selection[0]) are as safe as any other
            // active-page node reference.
            if (name === "selection") return "NodeList";
            if (name === "artboards" || name === "allChildren" || name === "allDescendants" || name === "children" || name === "documentRoot") {
                const baseType = inferType(base, visited, depth + 1);
                if (baseType === "PageNode" || baseType === "InactiveNodeList") return "InactiveNodeList";
                return "NodeList";
            }
            if (name === "context") return "EditorContext";
        } else if (kind === SyntaxKind.CallExpression) {
            const propAccess = expr.getExpressionIfKind(SyntaxKind.PropertyAccessExpression);
            if (propAccess) {
                const name = propAccess.getName();
                if (name === "addPage") return "ActivePageNode";
                if (name === "getItem") {
                    const baseType = inferType(propAccess.getExpression(), visited, depth + 1);
                    if (baseType === "PageList") return "PageNode";
                    if (baseType === "NodeList") return "SafeContainer";
                }
            }
        } else if (kind === SyntaxKind.ElementAccessExpression) {
            const baseType = inferType(expr.getExpression(), visited, depth + 1);
            if (baseType === "PageList") return "PageNode";
            if (baseType === "NodeList") return "SafeContainer";
        } else if (kind === SyntaxKind.AsExpression || kind === SyntaxKind.TypeAssertion || kind === SyntaxKind.ParenthesizedExpression || kind === SyntaxKind.NonNullExpression) {
            return inferType(expr.getExpression(), visited, depth + 1);
        } else if (kind === SyntaxKind.BinaryExpression && expr.getOperatorToken().getKind() === SyntaxKind.EqualsToken) {
            return inferType(expr.getRight(), visited, depth + 1);
        }

        return "Unknown";
    }

    // Traces an expression through local variable aliases back to an SDK
    // alias, so `const page = editor.context.currentPage; page.allChildren`
    // is still recognized as SDK-related.
    function resolvesToSdk(node, visited = new Set()) {
        if (!node || visited.has(node)) return false;
        visited.add(node);
        const kind = node.getKind();
        if (kind === SyntaxKind.Identifier) {
            if (sdkAliases.has(node.getText())) return true;
            const symbol = node.getSymbol() || project.getTypeChecker().getSymbolAtLocation(node);
            if (!symbol) return false;
            const decls = symbol.getDeclarations() || [];
            for (const decl of decls) {
                if (decl.getKind() === SyntaxKind.VariableDeclaration) {
                    const init = decl.getInitializer();
                    if (init && resolvesToSdk(init, visited)) return true;
                } else if (decl.getKind() === SyntaxKind.BindingElement) {
                    const bindingDecl = decl.getFirstAncestorByKind(SyntaxKind.VariableDeclaration);
                    const init = bindingDecl && bindingDecl.getInitializer();
                    if (init && resolvesToSdk(init, visited)) return true;
                }
            }
            return false;
        }
        if (kind === SyntaxKind.PropertyAccessExpression || kind === SyntaxKind.ElementAccessExpression
            || kind === SyntaxKind.CallExpression || kind === SyntaxKind.NonNullExpression
            || kind === SyntaxKind.ParenthesizedExpression || kind === SyntaxKind.AsExpression) {
            return resolvesToSdk(node.getExpression(), visited);
        }
        return false;
    }

    // Bundlers commonly re-export the SDK's `editor` behind a webpack harmony
    // namespace object built via a runtime helper — e.g.
    // `const i = (e => { var t = {}; a.d(t, e); return t; })({ editor: () => t.editor })`
    // then call `i.editor.queueAsyncEdit(...)`. The getter lives on an object
    // literal passed as a call *argument*, so neither the identifier-alias
    // scan nor `resolvesToSdk` (which only follows call *callees*, not
    // arguments) ever traces `i` back to the SDK import. Rather than deep-
    // tracing every bundler's re-export shape, treat a receiver literally
    // named/accessed as `editor` as SDK-related directly — `editor.<member>`
    // is the documented unsafe-API shape regardless of how `editor` itself
    // was bound, and false-flagging an unrelated local var named `editor` is
    // an acceptable trade against silently missing a real hard-break call.
    function looksLikeEditorReceiver(node) {
        if (node.getKind() === SyntaxKind.Identifier && node.getText() === "editor") return true;
        if (node.getKind() === SyntaxKind.PropertyAccessExpression && node.getName() === "editor") return true;
        return false;
    }

    function checkIfSdkRelated(expressionNode) {
        if (sdkAliases.size === 0 && hasSdk) return true;
        if (looksLikeEditorReceiver(expressionNode)) return true;
        let isSdkRelated = false;
        expressionNode.forEachDescendant(node => {
            if (node.getKind() === SyntaxKind.Identifier && sdkAliases.has(node.getText())) isSdkRelated = true;
        });
        if (expressionNode.getKind() === SyntaxKind.Identifier && sdkAliases.has(expressionNode.getText())) isSdkRelated = true;
        if (!isSdkRelated) isSdkRelated = resolvesToSdk(expressionNode);
        // `resolvesToSdk` only walks declaration initializers — it has no
        // notion of "this identifier is the loop variable of a `for...of`
        // over an SDK-derived list" (e.g. `for (const page of doc.pages)`).
        // `inferType` already implements exactly that tracing (for-of over
        // a PageList/NodeList → PageNode/SafeContainer) but was only ever
        // invoked *after* this gate passed, so a real hazard on a plain
        // loop variable was silently dropped before inferType ever ran.
        // If inferType can resolve a concrete SDK shape, that alone proves
        // SDK origin, so trust it as a fallback here too.
        if (!isSdkRelated && inferType(expressionNode) !== "Unknown") isSdkRelated = true;
        return isSdkRelated;
    }

    // ---- Named-API detection (Tier 1 / Tier 2 + TypeFlow clearing) ----
    const apis = {};
    let tier1_hit = false;
    let tier2_hit = false;

    function recordHit(member, token, linePosNode, sourceFile, isSdkRelated, exprType) {
        if (!isSdkRelated) return;
        if (TIER_2.includes(member)) {
            if (member === "bringIntoView") {
                if (exprType === "ActivePageNode" || exprType === "SafeContainer") return;
                if (exprType === "PageNode") exprType = "Hazard:CrossPageNode";
            } else {
                if (exprType === "ActivePageNode" || exprType === "SafeContainer") return;
                if (exprType === "PageNode") exprType = "Hazard:PageNode";
            }
        }
        const tier = TIER_1.includes(member) ? 1 : 2;
        if (tier === 1) tier1_hit = true;
        if (tier === 2) tier2_hit = true;
        if (!apis[member]) apis[member] = { count: 0, tier, tokens: [], files_hit: {} };
        apis[member].count++;
        apis[member].tokens.push(`${token} (${exprType})`);
        const lc = sourceFile.getLineAndColumnAtPos(linePosNode.getStart());
        const filePath = sourceFile.getFilePath();
        if (!apis[member].files_hit[filePath]) apis[member].files_hit[filePath] = { file: filePath, lines: [] };
        apis[member].files_hit[filePath].lines.push(lc.line);
    }

    project.getSourceFiles().forEach(sourceFile => {
        sourceFile.getDescendantsOfKind(SyntaxKind.PropertyAccessExpression).forEach(propAccess => {
            const member = propAccess.getName();
            if (!ALL_MEMBERS.includes(member)) return;
            let current = propAccess.getExpression();
            let typeOrigin = current;
            // bringIntoView cares about its argument's staleness, not its receiver.
            if (member === "bringIntoView") {
                const callExpr = propAccess.getParentIfKind(SyntaxKind.CallExpression);
                if (callExpr && callExpr.getExpression() === propAccess) {
                    const args = callExpr.getArguments();
                    if (args.length > 0) typeOrigin = args[0];
                }
            }
            let token = typeOrigin.getKind() === SyntaxKind.Identifier ? typeOrigin.getText() : "unknown";
            if (typeOrigin.getKind() === SyntaxKind.PropertyAccessExpression) token = typeOrigin.getText();
            const isSdkRelated = checkIfSdkRelated(current);
            const exprType = isSdkRelated ? inferType(typeOrigin) : "Unknown";
            recordHit(member, token, propAccess, sourceFile, isSdkRelated, exprType);
        });

        sourceFile.getDescendantsOfKind(SyntaxKind.ElementAccessExpression).forEach(elemAccess => {
            const arg = elemAccess.getArgumentExpression();
            if (arg && arg.getKind() === SyntaxKind.StringLiteral) {
                const member = arg.getLiteralText();
                if (!ALL_MEMBERS.includes(member)) return;
                const current = elemAccess.getExpression();
                const token = current.getKind() === SyntaxKind.Identifier ? current.getText() : "unknown";
                const isSdkRelated = checkIfSdkRelated(current);
                const exprType = isSdkRelated ? inferType(current) : "Unknown";
                recordHit(member, token, elemAccess, sourceFile, isSdkRelated, exprType);
            }
        });
    });

    const formattedApis = {};
    for (const mem in apis) {
        const uniqueTokens = [...new Set(apis[mem].tokens)];
        const filesHit = Object.values(apis[mem].files_hit).map(f => {
            f.lines = [...new Set(f.lines)].sort((a, b) => a - b);
            return f;
        });
        formattedApis[mem] = { count: apis[mem].count, tier: apis[mem].tier, tokens: uniqueTokens, files_hit: filesHit };
    }

    // ---- Pattern A (async gap) & Pattern B (module persistence) ----
    let patternA_hits = [];
    let patternB_hits = [];
    let patternC_hits = [];

    // A few Editor SDK methods return a Promise but are themselves doc-mutating
    // and need an edit-allowed context (see references/safe-patterns.md's
    // "Doc-mutating async APIs" table). The edit-allowed window only lasts for
    // one bounded gap, so calling one of these more than once — or once after
    // other unrelated async work already happened — throws even with a fresh,
    // non-stale node reference. `visitPages` is the one construct that keeps
    // edits allowed across its callback's entire duration.
    const DOC_MUTATING_ASYNC_METHODS = new Set(["loadBitmapImage", "createRendition", "replaceMediaWithEditedImage"]);

    const FUNCTION_KINDS = [SyntaxKind.FunctionDeclaration, SyntaxKind.ArrowFunction, SyntaxKind.FunctionExpression, SyntaxKind.MethodDeclaration];

    function isVisitPagesCallback(fn) {
        let current = fn;
        while (current) {
            const enclosingCall = current.getParentIfKind(SyntaxKind.CallExpression);
            if (enclosingCall) {
                const propEx = enclosingCall.getExpressionIfKind(SyntaxKind.PropertyAccessExpression);
                if (propEx && propEx.getName() === "visitPages") {
                    const args = enclosingCall.getArguments();
                    if (args[args.length - 1] === current) return true;
                }
            }
            // A doc-mutating call can be nested in a helper function that is
            // itself defined inside the visitPages callback — walk out to the
            // next enclosing function and check it too.
            current = current.getAncestors().find(a => FUNCTION_KINDS.includes(a.getKind()));
        }
        return false;
    }

    function checkPatternC(func, sourceFile) {
        if (isVisitPagesCallback(func)) return;

        const isDirectChildOfFunc = (node) => {
            let p = node.getParent();
            while (p && p !== func) {
                if (FUNCTION_KINDS.includes(p.getKind())) return false;
                p = p.getParent();
            }
            return p === func;
        };

        const awaits = func.getDescendantsOfKind(SyntaxKind.AwaitExpression).filter(isDirectChildOfFunc);

        const mutatingCalls = func.getDescendantsOfKind(SyntaxKind.CallExpression)
            .filter(isDirectChildOfFunc)
            .filter(call => {
                const propEx = call.getExpressionIfKind(SyntaxKind.PropertyAccessExpression);
                if (!propEx || !DOC_MUTATING_ASYNC_METHODS.has(propEx.getName())) return false;
                // Gate on SDK-relatedness like the named-API detector above,
                // so an unrelated object with a same-named method (e.g. a
                // custom createRendition helper) isn't mistaken for the SDK's.
                return checkIfSdkRelated(propEx.getExpression());
            })
            .sort((a, b) => a.getStart() - b.getStart());

        mutatingCalls.forEach((call, index) => {
            const hasEarlierAwait = awaits.some(aw => aw.getEnd() <= call.getStart());
            if (index === 0 && !hasEarlierAwait) return;

            const propEx = call.getExpressionIfKind(SyntaxKind.PropertyAccessExpression);
            patternC_hits.push({
                file: sourceFile.getFilePath(),
                line: sourceFile.getLineAndColumnAtPos(call.getStart()).line,
                token: propEx.getName()
            });
        });
    }

    function checkPatternA(func, sourceFile) {
        const isDirectChildOfFunc = (node) => {
            let p = node.getParent();
            while (p && p !== func) {
                if (p.getKind() === SyntaxKind.FunctionDeclaration || p.getKind() === SyntaxKind.ArrowFunction || p.getKind() === SyntaxKind.FunctionExpression || p.getKind() === SyntaxKind.MethodDeclaration) return false;
                p = p.getParent();
            }
            return p === func;
        };

        const awaits = func.getDescendantsOfKind(SyntaxKind.AwaitExpression).filter(isDirectChildOfFunc);

        let isAsyncCallback = false;
        const parentCall = func.getParentIfKind(SyntaxKind.CallExpression);
        if (parentCall) {
            const text = parentCall.getExpression().getText();
            if (text === "setTimeout" || text === "setInterval" || /\.(then|catch|finally)$/.test(text)) isAsyncCallback = true;
        }

        if (awaits.length === 0 && !isAsyncCallback) return;

        const funcLoc = func.getStart();
        const directIdentifiers = func.getDescendantsOfKind(SyntaxKind.Identifier).filter(isDirectChildOfFunc);

        directIdentifiers.forEach(id => {
            const pNode = id.getParent();
            if (pNode && (pNode.getKind() === SyntaxKind.VariableDeclaration || pNode.getKind() === SyntaxKind.BindingElement)) {
                if (pNode.getNameNode() === id) return;
            }
            const decl = getScopeDecl(id);
            if (!decl) return;
            const declPos = decl.getStart();
            let crossedAsync = false;

            // "Crossed" = used after the await *expression* resolves, not merely
            // after the `await` keyword; an outer var passed as an argument to
            // the awaited call itself (`await f(outerVar)`) is not a stale risk.
            if (isAsyncCallback && declPos < funcLoc) {
                crossedAsync = true;
            } else if (declPos >= funcLoc) {
                for (const aw of awaits) {
                    if (declPos < aw.getStart() && id.getStart() > aw.getEnd()) { crossedAsync = true; break; }
                }
            } else {
                for (const aw of awaits) {
                    if (id.getStart() > aw.getEnd()) { crossedAsync = true; break; }
                }
            }

            if (!crossedAsync) return;

            const typeString = inferType(id);
            if (!(typeString === "ActivePageNode" || typeString === "SafeContainer" || typeString === "NodeList" || typeString === "PageNode")) return;

            let protectedStatus = false;
            // `func` is the (possibly nested) callback where the crossing happens.
            // Protection comes from *how func itself was passed* to a call, not
            // from anything between `id` and `func` — `id` and `func`'s enclosing
            // call are siblings in that sense, so check func's own parent call.
            const enclosingCall = func.getParentIfKind(SyntaxKind.CallExpression);
            if (enclosingCall) {
                const propEx = enclosingCall.getExpressionIfKind(SyntaxKind.PropertyAccessExpression);
                const args = enclosingCall.getArguments();
                if (propEx && propEx.getName() === "keepContentActiveDuringAsync" && args.length >= 3 && args[2] === func) {
                    if (args[0].getText() === id.getText() || (decl.getNameNode() && args[0].getText() === decl.getNameNode().getText())) {
                        protectedStatus = true;
                    }
                } else if (propEx && propEx.getName() === "visitPages" && args[args.length - 1] === func) {
                    // visitPages keeps edits allowed for the callback's entire
                    // duration, including further internal awaits — unlike
                    // keepContentActiveDuringAsync it has no explicit "target"
                    // argument to match against, so any identifier that already
                    // passed the page-context TypeFlow check above is treated as
                    // protected when the crossing happens inside this callback.
                    protectedStatus = true;
                }
            }

            if (!protectedStatus) {
                patternA_hits.push({
                    file: sourceFile.getFilePath(),
                    line: sourceFile.getLineAndColumnAtPos(id.getStart()).line,
                    token: id.getText()
                });
            }
        });
    }

    const moduleVars = new Set();
    project.getSourceFiles().forEach(sourceFile => {
        sourceFile.getDescendantsOfKind(SyntaxKind.VariableDeclaration).forEach(decl => {
            if (decl.getFirstAncestorByKind(SyntaxKind.Block) === undefined) moduleVars.add(decl.getName());
        });
    });

    project.getSourceFiles().forEach(sourceFile => {
        sourceFile.getDescendantsOfKind(SyntaxKind.FunctionDeclaration).forEach(f => { checkPatternA(f, sourceFile); checkPatternC(f, sourceFile); });
        sourceFile.getDescendantsOfKind(SyntaxKind.ArrowFunction).forEach(f => { checkPatternA(f, sourceFile); checkPatternC(f, sourceFile); });
        sourceFile.getDescendantsOfKind(SyntaxKind.FunctionExpression).forEach(f => { checkPatternA(f, sourceFile); checkPatternC(f, sourceFile); });
        sourceFile.getDescendantsOfKind(SyntaxKind.MethodDeclaration).forEach(f => { checkPatternA(f, sourceFile); checkPatternC(f, sourceFile); });

        sourceFile.getDescendantsOfKind(SyntaxKind.Identifier).forEach(id => {
            const parent = id.getParent();
            if (parent && (parent.getKind() === SyntaxKind.VariableDeclaration || parent.getKind() === SyntaxKind.BindingElement)) {
                if (parent.getNameNode() === id) return;
            }
            if (!moduleVars.has(id.getText())) return;

            const decl = getScopeDecl(id);
            if (!(decl && decl.getFirstAncestorByKind(SyntaxKind.Block) === undefined)) return;

            const func = id.getFirstAncestorByKind(SyntaxKind.FunctionDeclaration)
                || id.getFirstAncestorByKind(SyntaxKind.ArrowFunction)
                || id.getFirstAncestorByKind(SyntaxKind.MethodDeclaration);
            if (!func) return;

            const t = inferType(id);
            if (!(t === "ActivePageNode" || t === "SafeContainer" || t === "PageNode" || t === "NodeList")) return;

            let isAssignment = false;
            const parentBin = id.getParentIfKind(SyntaxKind.BinaryExpression);
            if (parentBin && parentBin.getOperatorToken().getKind() === SyntaxKind.EqualsToken && parentBin.getLeft() === id) {
                isAssignment = true;
            }
            // Note: a property assignment on the stale ref (rect.fill = ...) is
            // NOT cleared — mutating a stale node throws just like a read.

            if (!isAssignment) {
                patternB_hits.push({
                    file: sourceFile.getFilePath(),
                    line: sourceFile.getLineAndColumnAtPos(id.getStart()).line,
                    token: id.getText()
                });
            }
        });
    });

    function dedupeHits(hits) {
        const seen = new Set();
        return hits.filter(h => {
            const key = `${h.file}:${h.line}:${h.token}`;
            if (seen.has(key)) return false;
            seen.add(key);
            return true;
        });
    }
    patternA_hits = dedupeHits(patternA_hits);
    patternB_hits = dedupeHits(patternB_hits);
    patternC_hits = dedupeHits(patternC_hits);

    return {
        hasSdk: true,
        named_api_hit: Object.keys(formattedApis).length > 0,
        tier1_hit,
        tier2_hit,
        apis: formattedApis,
        patternA_hits,
        patternB_hits,
        patternC_hits,
        skipped_no_sdk: false
    };
}

module.exports = { analyze, TIER_1, TIER_2, SDK_MODULES };
