import { editor } from "express-document-sdk";

// Tier 2 cleared by TypeFlow: allChildren on the active page is safe.
export function run() {
    return editor.context.currentPage.allChildren;
}
