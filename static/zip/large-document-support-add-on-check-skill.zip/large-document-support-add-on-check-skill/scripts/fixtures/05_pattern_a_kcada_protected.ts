import { editor } from "express-document-sdk";
import type { TextNode } from "express-document-sdk";

// Pattern A must NOT fire: keepContentActiveDuringAsync protects the node.
export async function run(proxy: { t(s: string): Promise<string> }) {
    const textNode = editor.context.selection[0] as TextNode;
    await editor.keepContentActiveDuringAsync(
        textNode,
        async () => proxy.t(textNode.fullContent.text),
        (translated) => { textNode.fullContent.text = translated; }
    );
}
