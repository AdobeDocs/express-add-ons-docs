import { editor } from "express-document-sdk";
import type { VisualNode } from "express-document-sdk";

// Pattern A must NOT fire: visitPages keeps edits allowed across its own
// internal awaits, so a node captured before the call is safe to use again
// inside the callback even after an earlier awaited createRendition() call.
// Scoped to [currentPage] since node is already on the active page — not
// [...pages], which would only be correct if every page needed visiting.
export async function run() {
    const node = editor.context.selection[0] as VisualNode;
    await editor.documentRoot.pages.visitPages([editor.context.currentPage], async () => {
        const first = await node.createRendition({ format: "png" as any });
        const second = await node.createRendition({ format: "png" as any });
        return [first, second];
    });
}
