import { editor } from "express-document-sdk";

// Safe: an outer var passed as an argument to the very call being awaited is
// NOT a stale risk (guards the aw.getStart() -> aw.getEnd() precision fix).
export async function run() {
    const node = editor.context.selection[0];
    await editor.keepContentActiveDuringAsync(node, async () => {}, () => {
        node.rotation = 5;
    });
}
