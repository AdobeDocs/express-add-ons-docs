import { editor } from "express-document-sdk";

// Safe: fully synchronous create + configure + append on the active page.
export function run() {
    const rect = editor.createRectangle();
    rect.width = 200;
    rect.height = 150;
    editor.context.insertionParent.children.append(rect);
}
