import { editor } from "express-document-sdk";

// Tier 2 hazard reached through a `for...of` loop variable — the loop
// variable's own symbol declaration has no initializer (there's no `=` in
// `for (const page of ...)`), so tracing it back to the SDK-derived
// iterable requires walking out to the ForOfStatement's iterable
// expression, not the (non-existent) initializer.
export function run() {
    const doc = editor.documentRoot;
    for (const page of doc.pages) {
        if (page.artboards) {
            console.log(page.artboards.length);
        }
    }
}
