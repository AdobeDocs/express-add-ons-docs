import { editor } from "express-document-sdk";

// Pattern B: node cached at module scope and reused later -> stale hazard.
let cachedNode = editor.context.selection[0];

export function later() {
    cachedNode.rotation = 5;
}
