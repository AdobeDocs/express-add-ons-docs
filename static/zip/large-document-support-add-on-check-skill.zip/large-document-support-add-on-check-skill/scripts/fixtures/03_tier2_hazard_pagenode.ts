import { editor } from "express-document-sdk";

// Tier 2 hazard: `first` yields a PageNode (not the active page), so
// allChildren on it is a genuine Large Document Support break -> Hazard:PageNode.
export function run() {
    const page = editor.documentRoot.pages.first;
    return page.allChildren;
}
