import { editor } from "express-document-sdk";

// Pattern C must fire: createRendition called twice in the same function with
// no visitPages — the edit-allowed window only lasts one bounded gap, so the
// second call throws even though `node` itself is a fresh, non-stale reference
// (created synchronously right here, so Pattern A doesn't apply either).
export async function renderTwice() {
    const node = editor.createRectangle();
    const first = await node.createRendition({ format: "png" as any });
    const second = await node.createRendition({ format: "png" as any });
    return [first, second];
}
