// No SDK import at all — must be skipped, never flagged, and must not crash
// despite having declarations, functions, and awaits.
export async function unrelated() {
    const value = await fetch("https://example.com");
    const items = [1, 2, 3];
    return items.map((x) => x * 2).concat([value.status]);
}
