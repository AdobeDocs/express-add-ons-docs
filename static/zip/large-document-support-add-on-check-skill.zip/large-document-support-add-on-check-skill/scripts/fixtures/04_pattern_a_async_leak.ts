import { editor } from "express-document-sdk";

// Pattern A: node captured before await, read after -> stale-reference hazard.
export async function run(proxy: { delay(n: number): Promise<void> }) {
    const rect = editor.context.selection[0];
    await proxy.delay(1000);
    return rect.translation;
}
