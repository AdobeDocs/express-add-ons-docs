import * as e from "add-on-sdk-document-sandbox";
import * as t from "express-document-sdk";

// Tier 1 hard break, reached through a webpack harmony namespace re-export
// of `editor` — the getter lives on an object literal passed as a call
// *argument*, so identifier-alias scanning and resolvesToSdk (which only
// follows call callees) both miss it without the `editor`-receiver
// heuristic in checkIfSdkRelated. Mirrors a real minified add-on bundle
// (`i.editor.queueAsyncEdit(...)`, `t` = express-document-sdk namespace).
var a = {
    d: (e: any, t: any) => {
        for (var n in t) a.o(t, n) && !a.o(e, n) && Object.defineProperty(e, n, { enumerable: true, get: t[n] });
    },
    o: (e: any, t: any) => Object.prototype.hasOwnProperty.call(e, t),
};
const i: any = ((e: any) => {
    var t: any = {};
    return a.d(t, e), t;
})({ editor: () => t.editor });

export async function run() {
    await i.editor.queueAsyncEdit(() => {
        i.editor.createText("hi");
    });
}
