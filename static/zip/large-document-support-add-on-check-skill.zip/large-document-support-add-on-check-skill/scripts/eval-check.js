#!/usr/bin/env node
// Regression gate for the Large Document Support detection engine.
//
// Runs large-document-support-core.analyze() over every fixture in fixtures/
// and checks the result against the pinned expectations in
// fixtures/manifest.json. Run after any change to large-document-support-core.js
// or check-large-document-support.js:  node scripts/eval-check.js
//
// Exits non-zero (and prints every failure) if any fixture's result doesn't
// match its expectation.

const fs = require("fs");
const path = require("path");

const core = require("./large-document-support-core.js");

const FIXTURES_DIR = path.join(__dirname, "fixtures");

function analyzeFixture(fname) {
    const fpath = path.join(FIXTURES_DIR, fname);
    const content = fs.readFileSync(fpath, "utf-8");
    return core.analyze([{ path: fpath, content }]);
}

function checkCase(c) {
    const failures = [];
    const { file: fname, expect } = c;
    let actual;
    try {
        actual = analyzeFixture(fname);
    } catch (e) {
        return [`${fname}: analyzer threw: ${e && e.stack ? e.stack : e}`];
    }

    const apis = actual.apis || {};
    const patternA = actual.patternA_hits || [];
    const patternB = actual.patternB_hits || [];
    const patternC = actual.patternC_hits || [];

    for (const key of ["hasSdk", "named_api_hit", "tier1_hit", "tier2_hit", "skipped_no_sdk"]) {
        if (key in expect && (actual[key] || false) !== expect[key]) {
            failures.push(`${fname}: expected ${key}=${JSON.stringify(expect[key])}, got ${JSON.stringify(actual[key])}`);
        }
    }

    if ("apis_has" in expect) {
        for (const member of expect.apis_has) {
            if (!(member in apis)) failures.push(`${fname}: expected apis to include '${member}', got [${Object.keys(apis)}]`);
        }
        if (expect.apis_has.length === 0 && Object.keys(apis).length > 0) {
            failures.push(`${fname}: expected apis to be empty, got [${Object.keys(apis)}]`);
        }
    }

    if ("api_counts" in expect) {
        for (const [member, count] of Object.entries(expect.api_counts)) {
            const actualCount = apis[member] && apis[member].count;
            if (actualCount !== count) failures.push(`${fname}: expected '${member}' count ${count}, got ${actualCount}`);
        }
    }

    if ("hazard_tokens_contain" in expect) {
        const allTokens = Object.values(apis).flatMap(d => d.tokens || []);
        if (!allTokens.some(t => t.includes(expect.hazard_tokens_contain))) {
            failures.push(`${fname}: expected a token containing '${expect.hazard_tokens_contain}', got ${JSON.stringify(allTokens)}`);
        }
    }

    if ("patternA_count" in expect && patternA.length !== expect.patternA_count) {
        failures.push(`${fname}: expected patternA count ${expect.patternA_count}, got ${patternA.length}`);
    }
    if ("patternA_count_min" in expect && patternA.length < expect.patternA_count_min) {
        failures.push(`${fname}: expected patternA count >= ${expect.patternA_count_min}, got ${patternA.length}`);
    }
    if ("patternB_count" in expect && patternB.length !== expect.patternB_count) {
        failures.push(`${fname}: expected patternB count ${expect.patternB_count}, got ${patternB.length}`);
    }
    if ("patternB_count_min" in expect && patternB.length < expect.patternB_count_min) {
        failures.push(`${fname}: expected patternB count >= ${expect.patternB_count_min}, got ${patternB.length}`);
    }
    if ("patternC_count" in expect && patternC.length !== expect.patternC_count) {
        failures.push(`${fname}: expected patternC count ${expect.patternC_count}, got ${patternC.length}`);
    }
    if ("patternC_count_min" in expect && patternC.length < expect.patternC_count_min) {
        failures.push(`${fname}: expected patternC count >= ${expect.patternC_count_min}, got ${patternC.length}`);
    }

    return failures;
}

function main() {
    if (!core.analyze) {
        process.stderr.write(`Setup error: could not load ts-morph. The first run fetches it automatically and needs Node.js/npm on PATH plus network access.\n(${core.loadError})\n`);
        return 2;
    }
    const manifest = JSON.parse(fs.readFileSync(path.join(FIXTURES_DIR, "manifest.json"), "utf-8"));
    const total = manifest.cases.length;
    const allFailures = [];
    for (const c of manifest.cases) {
        const failures = checkCase(c);
        console.log(`[${failures.length ? "FAIL" : "PASS"}] ${c.file}`);
        allFailures.push(...failures);
    }
    if (allFailures.length) {
        console.log(`\n${allFailures.length} assertion failure(s) across ${total} fixtures:`);
        for (const f of allFailures) console.log(`  - ${f}`);
        return 1;
    }
    console.log(`\nAll ${total} fixtures passed.`);
    return 0;
}

process.exit(main());
