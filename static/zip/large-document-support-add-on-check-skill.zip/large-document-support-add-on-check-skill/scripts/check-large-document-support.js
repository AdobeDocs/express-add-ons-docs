#!/usr/bin/env node
// Large Document Support safety checker (CLI).
//
// Runs the source-mode Large Document Support detection engine over an
// add-on's source and turns the raw detection result into developer-facing
// findings: what's unsafe, where, why, and how to fix it. Exits non-zero when
// hazards are found so it doubles as a CI / pre-commit gate.
//
// Usage:
//   node check-large-document-support.js <path>            # add-on folder, src/ folder, or a single file
//   node check-large-document-support.js <path> --json     # machine-readable JSON to stdout
//   node check-large-document-support.js <path> --report <dir>   # also write large-document-support-report.json + large-document-support-report.md
//   node check-large-document-support.js --help

const fs = require("fs");
const path = require("path");

// large-document-support-core is required lazily inside main() (after the
// --help short-circuit) so that `--help` never triggers the on-demand
// ts-morph fetch.

const SOURCE_EXT = new Set([".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs"]);
const SKIP_DIRS = new Set(["node_modules", "dist", "build", "out", ".git", "recovered", "coverage"]);

// ---- fix guidance keyed to safe-patterns.md sections ----
const FIX = {
    tier1_queueAsyncEdit: {
        why: "`queueAsyncEdit` is removed under Large Document Support.",
        fix: "Replace with `editor.keepContentActiveDuringAsync(node, asyncWork, applyEdit)`, which pins the node's page across the async gap and applies the edit while the page is still active. If `asyncWork` itself needs to call a doc-mutating SDK method (e.g. `loadBitmapImage`, `createRendition`), await that call BEFORE `keepContentActiveDuringAsync`, not inside `asyncWork` — it throws there.",
        ref: "references/safe-patterns.md#queueasyncedit-removed"
    },
    tier2_hazard: {
        why: "This API is called on a node that is not provably on the *active* page (e.g. a page reached via `.pages`, `.first`, `.artboards`), so under Large Document Support the receiver may already be inactive.",
        fix: "Only traverse from `editor.context.currentPage` / `editor.context.insertionParent`, or wrap cross-page work in `pages.visitPages(...)` so each page is active during its own callback.",
        ref: "references/safe-patterns.md#tier-2-context-dependent-apis"
    },
    tier2_unknown: {
        why: "This is a context-dependent API and the checker could not prove the receiver is the active page.",
        fix: "Confirm the receiver comes from `editor.context.currentPage` / `insertionParent`. If it does, it's safe; if it can be another page, traverse via `visitPages` instead.",
        ref: "references/safe-patterns.md#tier-2-context-dependent-apis"
    },
    patternA: {
        why: "A node reference captured before an `await` is used after it. If the user navigates to another page during the await, that node is stale and any access throws.",
        fix: "Don't hold the node across the gap — wrap the async work in `editor.keepContentActiveDuringAsync(node, asyncWork, applyEdit)`, or re-fetch the node from `editor.context` after the await. Doc-mutating calls like `loadBitmapImage` must resolve before `keepContentActiveDuringAsync`, not inside `asyncWork`.",
        ref: "references/safe-patterns.md#pattern-a-async-gap"
    },
    patternB: {
        why: "A node reference is stored at module scope and reused in a later call. If the user navigated between calls, the stored node is stale.",
        fix: "Don't persist node references across invocations. Store a stable id / your own model instead, and re-fetch the node from the document at the start of each call.",
        ref: "references/safe-patterns.md#pattern-b-persisted-reference"
    },
    patternC: {
        why: "This doc-mutating async method (e.g. loadBitmapImage, createRendition, replaceMediaWithEditedImage) is called more than once, or after other async work already happened, in the same function without `visitPages`. The document's edit-allowed window only lasts for one bounded gap, so this call throws even though the node reference itself may be fresh, not stale.",
        fix: "Wrap all such calls in `pages.visitPages([...], async () => { ... })` instead — it keeps edits allowed for the callback's entire duration, not just one gap.",
        ref: "references/safe-patterns.md#calling-a-doc-mutating-method-more-than-once-or-after-other-async-work"
    }
};

function parseArgs(argv) {
    const args = { target: null, json: false, reportDir: null, help: false };
    for (let i = 0; i < argv.length; i++) {
        const a = argv[i];
        if (a === "--help" || a === "-h") args.help = true;
        else if (a === "--json") args.json = true;
        else if (a === "--report") args.reportDir = argv[++i] || ".";
        else if (!args.target) args.target = a;
    }
    return args;
}

function printHelp() {
    process.stdout.write(`large-document-support-safety-check — flag Adobe Express add-on code that breaks under Large Document Support

Usage:
  node check-large-document-support.js <path> [--json] [--report <dir>]

  <path>            Add-on folder, its src/ folder, or a single sandbox file.
  --json            Emit the full result as JSON to stdout (for tooling).
  --report <dir>    Also write large-document-support-report.json and large-document-support-report.md into <dir>.
  --help            Show this help.

Exit codes: 0 = safe, 1 = hazards found, 2 = usage/setup error.
`);
}

function walkSourceFiles(dir, acc) {
    let entries;
    try {
        entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch (e) {
        return acc;
    }
    for (const ent of entries) {
        if (ent.isDirectory()) {
            if (SKIP_DIRS.has(ent.name) || ent.name.startsWith(".")) continue;
            walkSourceFiles(path.join(dir, ent.name), acc);
        } else if (ent.isFile() && SOURCE_EXT.has(path.extname(ent.name))) {
            acc.push(path.join(dir, ent.name));
        }
    }
    return acc;
}

function findManifest(dir) {
    const candidates = [path.join(dir, "src", "manifest.json"), path.join(dir, "manifest.json")];
    return candidates.find(p => fs.existsSync(p)) || null;
}

function hasDocumentSandbox(manifestPath) {
    try {
        const m = JSON.parse(fs.readFileSync(manifestPath, "utf-8"));
        const entries = m.entryPoints || [];
        return entries.some(e => e && (e.documentSandbox || e.script));
    } catch (e) {
        return null; // unreadable — don't gate on it
    }
}

// Resolve the target into { files, srcRoot, manifestPath, uiOnly }.
function resolveTarget(target) {
    const abs = path.resolve(target);
    if (!fs.existsSync(abs)) return { error: `Path not found: ${abs}` };

    const stat = fs.statSync(abs);
    if (stat.isFile()) {
        if (!SOURCE_EXT.has(path.extname(abs))) return { error: `Not a source file: ${abs}` };
        return { files: [abs], srcRoot: path.dirname(abs), manifestPath: null, uiOnly: false };
    }

    const manifestPath = findManifest(abs);
    if (manifestPath) {
        const ds = hasDocumentSandbox(manifestPath);
        if (ds === false) {
            return { files: [], srcRoot: abs, manifestPath, uiOnly: true };
        }
    }
    const srcDir = fs.existsSync(path.join(abs, "src")) ? path.join(abs, "src") : abs;
    const files = walkSourceFiles(srcDir, []);
    return { files, srcRoot: srcDir, manifestPath, uiOnly: false };
}

// Turn a raw engine result into a flat, sorted list of findings.
function toFindings(result) {
    const findings = [];
    for (const member in result.apis) {
        const data = result.apis[member];
        const isTier1 = data.tier === 1;
        for (const fh of data.files_hit) {
            for (const line of fh.lines) {
                let kind, severity;
                if (isTier1) {
                    kind = "tier1_queueAsyncEdit";
                    severity = "error";
                } else {
                    const hazard = data.tokens.some(t => t.includes("Hazard:"));
                    kind = hazard ? "tier2_hazard" : "tier2_unknown";
                    severity = hazard ? "error" : "warning";
                }
                findings.push({ severity, rule: kind, api: member, file: fh.file, line, ...FIX[kind] });
            }
        }
    }
    for (const h of result.patternA_hits || []) {
        findings.push({ severity: "error", rule: "patternA", token: h.token, file: h.file, line: h.line, ...FIX.patternA });
    }
    for (const h of result.patternB_hits || []) {
        findings.push({ severity: "error", rule: "patternB", token: h.token, file: h.file, line: h.line, ...FIX.patternB });
    }
    for (const h of result.patternC_hits || []) {
        findings.push({ severity: "error", rule: "patternC", token: h.token, file: h.file, line: h.line, ...FIX.patternC });
    }
    findings.sort((a, b) => (a.file || "").localeCompare(b.file || "") || (a.line || 0) - (b.line || 0));
    return findings;
}

function rel(p, root) {
    try { return path.relative(process.cwd(), p) || p; } catch (e) { return p; }
}

function printHuman(findings, ctx) {
    const w = process.stdout;
    if (ctx.uiOnly) {
        w.write("✓ UI-only add-on (no documentSandbox entry) — out of scope for Large Document Support node-reference analysis.\n");
        return;
    }
    if (!ctx.hasSdk) {
        w.write("✓ No express-document-sdk usage found — nothing to check for Large Document Support safety.\n");
        return;
    }
    if (findings.length === 0) {
        w.write(`✓ Large-Document-Support-safe: scanned ${ctx.filesScanned} source file(s), no unsafe patterns found.\n`);
        return;
    }
    const errors = findings.filter(f => f.severity === "error").length;
    const warnings = findings.filter(f => f.severity === "warning").length;
    w.write(`✗ Large Document Support issues found: ${errors} error(s), ${warnings} warning(s) across ${ctx.filesScanned} file(s).\n\n`);
    for (const f of findings) {
        const tag = f.severity === "error" ? "ERROR" : "WARN ";
        const what = f.api ? `\`${f.api}\`` : `\`${f.token}\``;
        w.write(`  [${tag}] ${rel(f.file)}:${f.line}  (${f.rule}) ${what}\n`);
        w.write(`         Why: ${stripMd(f.why)}\n`);
        w.write(`         Fix: ${stripMd(f.fix)}\n`);
        w.write(`         See: ${f.ref}\n\n`);
    }
}

function stripMd(s) {
    return s.replace(/`/g, "");
}

function writeReport(dir, findings, ctx) {
    fs.mkdirSync(dir, { recursive: true });
    const json = {
        target: ctx.target,
        scannedAt: new Date().toISOString(),
        filesScanned: ctx.filesScanned,
        uiOnly: ctx.uiOnly,
        hasSdk: ctx.hasSdk,
        summary: {
            errors: findings.filter(f => f.severity === "error").length,
            warnings: findings.filter(f => f.severity === "warning").length
        },
        findings
    };
    fs.writeFileSync(path.join(dir, "large-document-support-report.json"), JSON.stringify(json, null, 2) + "\n");
    fs.writeFileSync(path.join(dir, "large-document-support-report.md"), renderMarkdown(json));
}

function renderMarkdown(json) {
    const lines = [];
    lines.push(`# Large Document Support Safety Report`);
    lines.push("");
    lines.push(`- **Target:** \`${json.target}\``);
    lines.push(`- **Scanned:** ${json.filesScanned} source file(s) at ${json.scannedAt}`);
    if (json.uiOnly) {
        lines.push(`- **Result:** UI-only add-on — out of scope for Large Document Support.`);
        return lines.join("\n") + "\n";
    }
    lines.push(`- **Errors:** ${json.summary.errors} · **Warnings:** ${json.summary.warnings}`);
    lines.push("");
    if (json.findings.length === 0) {
        lines.push(`✅ No Large-Document-Support-unsafe patterns found.`);
        return lines.join("\n") + "\n";
    }
    for (const f of json.findings) {
        const badge = f.severity === "error" ? "🔴 ERROR" : "🟡 WARNING";
        const what = f.api ? `\`${f.api}\`` : `\`${f.token}\``;
        lines.push(`## ${badge} — ${what} (${f.rule})`);
        lines.push(`\`${f.file}:${f.line}\``);
        lines.push("");
        lines.push(`**Why:** ${f.why}`);
        lines.push("");
        lines.push(`**Fix:** ${f.fix}`);
        lines.push("");
        lines.push(`See [\`${f.ref}\`](${f.ref}) for a before/after example.`);
        lines.push("");
    }
    return lines.join("\n") + "\n";
}

function main() {
    const args = parseArgs(process.argv.slice(2));
    if (args.help || !args.target) {
        printHelp();
        return args.help ? 0 : 2;
    }
    // Lazy require: loading large-document-support-core triggers the on-demand
    // ts-morph fetch, so it must happen only for a real run, not for --help.
    const core = require("./large-document-support-core.js");
    if (!core.analyze) {
        process.stderr.write(`Setup error: could not load the AST engine's dependency (ts-morph).\nThe first run fetches it automatically and needs Node.js/npm on PATH plus network access.\nDetails: ${core.loadError}\n`);
        return 2;
    }

    const resolved = resolveTarget(args.target);
    if (resolved.error) {
        process.stderr.write(`Error: ${resolved.error}\n`);
        return 2;
    }

    const ctx = { target: path.resolve(args.target), uiOnly: resolved.uiOnly, filesScanned: resolved.files.length, hasSdk: false };

    let findings = [];
    if (!resolved.uiOnly && resolved.files.length > 0) {
        const fileObjs = resolved.files.map(p => ({ path: p, content: fs.readFileSync(p, "utf-8") }));
        const result = core.analyze(fileObjs);
        ctx.hasSdk = result.hasSdk;
        findings = toFindings(result);
    }

    if (args.json) {
        process.stdout.write(JSON.stringify({ ...ctx, findings }, null, 2) + "\n");
    } else {
        printHuman(findings, ctx);
    }

    if (args.reportDir) writeReport(args.reportDir, findings, ctx);

    return findings.some(f => f.severity === "error") ? 1 : 0;
}

process.exit(main());
