# Large-Document-Support-safe patterns — fix recipes

Under **Large Document Support**, only the page the user is currently viewing
is active. Pages that scroll out of view become **inactive**, and any `Node`
reference to an inactive page throws `"Stale node reference"` on the next
access. Add-ons written before Large Document Support often hold node
references across time or reach into non-active pages — those break.

`large-document-support-safety-check` flags four situations. Each section
below shows **why** it breaks and a **before → after** fix. The `See:` pointer
in each finding maps to one of these anchors.

## Contents
- [`queueAsyncEdit` removed](#queueasyncedit-removed) — rule `tier1_queueAsyncEdit`
- [Doc-mutating async APIs and `keepContentActiveDuringAsync`](#doc-mutating-async-apis-and-keepcontentactiveduringasync)
  - [Calling a doc-mutating method more than once, or after other async work](#calling-a-doc-mutating-method-more-than-once-or-after-other-async-work)
- [Pattern A: async gap](#pattern-a-async-gap) — rule `patternA`
- [Pattern B: persisted reference](#pattern-b-persisted-reference) — rule `patternB`
- [Tier 2: context-dependent APIs](#tier-2-context-dependent-apis) — rules `tier2_hazard` / `tier2_unknown`

---

## `queueAsyncEdit` removed

`editor.queueAsyncEdit(...)` is removed under Large Document Support. It also never made a captured
node reference safe — the stale guard still fired inside its callback. The
replacement is `editor.keepContentActiveDuringAsync`, which keeps the node's
page active across the async gap and runs the edit callback while the page is
still guaranteed active.

**Before (breaks):**

```typescript
import { editor } from "express-document-sdk";

async function insertAfterLoad(imageBlob: Blob) {
    const parent = editor.context.insertionParent;
    const bitmap = await editor.loadBitmapImage(imageBlob);

    // ❌ queueAsyncEdit is removed; `parent` may also be stale by now
    await editor.queueAsyncEdit(() => {
        const media = editor.createImageContainer(bitmap);
        parent.children.append(media);
    });
}
```

**After (safe):**

```typescript
import { editor } from "express-document-sdk";

async function insertAfterLoad(imageBlob: Blob) {
    // editor.loadBitmapImage is itself a doc-mutating API — it must resolve
    // BEFORE keepContentActiveDuringAsync, never inside its asyncLambda.
    // See "Doc-mutating async APIs" below.
    const bitmap = await editor.loadBitmapImage(imageBlob);

    await editor.keepContentActiveDuringAsync(
        editor.context.insertionParent,
        async () => {}, // no further async work needed — bitmap is already loaded
        () => {
            // Runs while insertionParent's page is still guaranteed active
            const media = editor.createImageContainer(bitmap);
            editor.context.insertionParent.children.append(media);
        }
    );
}
```

---

## Doc-mutating async APIs and `keepContentActiveDuringAsync`

`keepContentActiveDuringAsync`'s `asyncLambda` runs with **document edits
blocked** — only `afterAsyncCallback` runs with edits allowed, and it must be
synchronous. A few Editor SDK methods return a `Promise` but are themselves
doc-mutating and require an edit-allowed context; calling one of these inside
`asyncLambda` throws `"Editing the document is not permitted in this context"`.
Never suggest nesting one of these inside `asyncLambda` — resolve it **before**
calling `keepContentActiveDuringAsync` (or inside a `pages.visitPages(...)`
callback, which keeps edits allowed across its own internal awaits), then do
the actual node edit in `afterAsyncCallback`.

| Method | Safe inside `asyncLambda`? |
|---|---|
| `editor.loadBitmapImage(...)` | No — await it before `keepContentActiveDuringAsync` |
| `node.createRendition(...)` | No — await it before `keepContentActiveDuringAsync` |
| `mediaContainerNode.replaceMediaWithEditedImage(...)` | No — await it before `keepContentActiveDuringAsync` |
| `editor.keepContentActiveDuringAsync(...)`, `editor.queueAsyncEdit(...)` | Yes |
| `pages.visitPages(...)` | Yes |
| `bitmapImage.data()`, `imageRectangleNode.fetchBitmapImage()`, `fonts.fromPostscriptName(...)` | Yes (read-only) |
| Your own UI-iframe proxy calls (`panelUIProxy.*`) | Yes |

This list can grow as the SDK adds methods. If you're unsure whether a method is
safe inside `asyncLambda`, the safe default is to treat it as unsafe: resolve it
before calling `keepContentActiveDuringAsync` instead of inside it.

### Calling a doc-mutating method more than once, or after other async work

`keepContentActiveDuringAsync` only supports **one** bounded async gap followed
by **one** synchronous edit — `afterAsyncCallback` isn't `async`, so you can't
await inside it. That doesn't work if you need to call a doc-mutating method
(like `createRendition`) **more than once**, or call one after other unrelated
async work has already happened. Doing so throws `"Editing the document is not
permitted in this context"` on the second call, even outside any `asyncLambda`.

Use `pages.visitPages([...pages], async () => { ... })` instead — it keeps edits
allowed for the **entire** callback, across any number of its own internal
awaits, not just one gap.

**Adapt the `pages` argument to the add-on's actual context — don't copy the
snippet below verbatim.** `[...pages]` (all pages) is only correct when the
work genuinely needs to touch every page. It is context-dependent, exactly like
every other fix in this doc (see "Offer to fix" in `SKILL.md`) — never
find-and-replace it in. Pick one of:
- **The node is already on the active page** (e.g. it came from
  `editor.context.selection`, `editor.context.currentPage`, or
  `editor.context.insertionParent`): pass `[editor.context.currentPage]`, not
  `[...pages]` — visiting every page does unnecessary work and can trigger the
  slow-visit progress dialog for no reason.
- **The node is on a different, non-active page:** you can't hold a reference
  to it from outside the callback at all — capture a stable id (see
  [Pattern B](#pattern-b-persisted-reference)) and the target `PageNode`
  instead, pass `[thatPage]`, then re-locate the node **inside** the callback
  from the `page` argument it receives (e.g. by id, or by walking
  `page.artboards`/`children`) rather than reusing an outside reference.

**Before (breaks on the second call):**

```typescript
import { editor } from "express-document-sdk";

async function renderTwice(node: { createRendition(opts: unknown): Promise<{ blob: Blob }> }) {
    const first = await node.createRendition({ format: "png" });
    // ❌ THROWS on the second call — not inside any keepContentActiveDuringAsync
    // asyncLambda, but the edit-allowed window from the first call has already closed
    const second = await node.createRendition({ format: "png" });
    return [first, second];
}
```

**After (safe) — node already on the active page, so only that page needs visiting:**

```typescript
import { editor } from "express-document-sdk";

async function renderTwice(node: { createRendition(opts: unknown): Promise<{ blob: Blob }> }) {
    let results: { blob: Blob }[] = [];
    // Only the active page is relevant here — not editor.documentRoot.pages.
    await editor.documentRoot.pages.visitPages([editor.context.currentPage], async () => {
        // Edits stay allowed here across both awaits, unlike keepContentActiveDuringAsync
        const first = await node.createRendition({ format: "png" });
        const second = await node.createRendition({ format: "png" });
        results = [first, second];
    });
    return results;
}
```

**After (safe) — node is on a different page: re-locate it inside the callback:**

```typescript
import { editor } from "express-document-sdk";
import type { PageNode } from "express-document-sdk";

// nodeId/targetPage were captured earlier (e.g. from a prior selection) —
// never the Node itself; see Pattern B.
async function renderOnOtherPage(targetPage: PageNode, nodeId: string) {
    let results: { blob: Blob }[] = [];
    await editor.documentRoot.pages.visitPages([targetPage], async (activePage) => {
        // Re-derive the node from the now-active page — do not reuse a
        // reference captured before the page was active.
        const node = findNodeById(activePage, nodeId);
        if (!node) return;
        const first = await node.createRendition({ format: "png" });
        const second = await node.createRendition({ format: "png" });
        results = [first, second];
    });
    return results;
}
```

---

## Pattern A: async gap

A node captured **before** an `await` is read or written **after** it. While the
add-on is suspended at the `await`, the user can navigate to another page; when
execution resumes the captured node is stale. This applies to any `await` —
`editor.loadBitmapImage(...)`, a UI iframe proxy call (`panelUIProxy.*`), or a
network request — even ones that feel instantaneous.

**Before (breaks):**

```typescript
import { editor } from "express-document-sdk";
import type { TextNode } from "express-document-sdk";

async function translate(panelUIProxy: { translateText(s: string): Promise<string> }) {
    const textNode = editor.context.selection[0] as TextNode;
    const original = textNode.fullContent.text;

    const translated = await panelUIProxy.translateText(original); // user navigates here

    textNode.fullContent.text = translated; // ❌ stale
}
```

**After (safe) — pin the node across the gap:**

```typescript
import { editor } from "express-document-sdk";
import type { TextNode } from "express-document-sdk";

async function translate(panelUIProxy: { translateText(s: string): Promise<string> }) {
    const textNode = editor.context.selection[0] as TextNode;
    const original = textNode.fullContent.text;

    await editor.keepContentActiveDuringAsync(
        textNode,
        async () => panelUIProxy.translateText(original),
        (translated) => { textNode.fullContent.text = translated; }
    );
}
```

**Alternative (safe) — don't hold the node; re-fetch after the await:**

```typescript
const original = (editor.context.selection[0] as TextNode).fullContent.text;
const translated = await panelUIProxy.translateText(original);
const fresh = editor.context.selection[0] as TextNode; // re-read from the live document
if (fresh) fresh.fullContent.text = translated;
```

---

## Pattern B: persisted reference

A node reference stored in a **module-level variable** (or any state that
outlives the call) and reused in a **later** invocation. It was valid when
stored, but if the user navigated between calls it is stale by the time it's
reused.

**Before (breaks):**

```typescript
import { editor } from "express-document-sdk";
import type { RectangleNode } from "express-document-sdk";

let heldRect: RectangleNode | undefined; // persists across button clicks

function onClick() {
    if (!heldRect) {
        heldRect = editor.createRectangle();
        editor.context.insertionParent.children.append(heldRect);
    } else {
        heldRect.width = 300; // ❌ stale if the user changed pages between clicks
    }
}
```

**After (safe) — persist an id, re-fetch the node each call:**

```typescript
import { editor } from "express-document-sdk";

let heldRectId: string | undefined; // persist a stable id, not the node

function onClick() {
    if (!heldRectId) {
        const rect = editor.createRectangle();
        editor.context.insertionParent.children.append(rect);
        heldRectId = rect.id;
    } else {
        // Re-fetch from the live document; only touch it if it's on the active page
        const rect = findNodeById(editor.context.currentPage, heldRectId);
        if (rect) rect.width = 300;
    }
}
```

---

## Tier 2: context-dependent APIs

`artboards`, `allChildren`, `allDescendants`, `allTextContent`, `cloneInPlace`,
and `bringIntoView` are only safe on the **active** page. They throw when the
receiver is a node reached via `.pages`, `.first`, `.artboards`, or any other
non-active-page traversal. The checker clears these automatically when it can
prove the receiver comes from `editor.context.currentPage` /
`editor.context.insertionParent`; a `warning` means it could not prove it.

**Before (breaks) — traversing a non-active page:**

```typescript
import { editor } from "express-document-sdk";

function countFirstPageChildren() {
    const firstPage = editor.documentRoot.pages.first; // not necessarily active
    return firstPage.allChildren.length; // ❌ throws if that page is inactive
}
```

**After (safe) — stay on the active page:**

```typescript
import { editor } from "express-document-sdk";

function countActivePageChildren() {
    return editor.context.currentPage.allChildren.length; // active page only
}
```

**After (safe) — iterate all pages with `visitPages`:**

```typescript
import { editor } from "express-document-sdk";

async function countAllPages() {
    const pages = editor.documentRoot.pages;
    let total = 0;
    // visitPages activates each page for the duration of its callback
    await pages.visitPages([...pages], async (page) => {
        total += page.allChildren.length; // `page` is active inside its callback
    });
    return total;
}
```

Never store a node obtained inside a `visitPages` callback and use it outside —
that reintroduces Pattern B.
